package com.grandmaconnect

/**
 * Pure rules for flow actions (Home, Back, Recents, internet panel, launch app) added
 * from the recording screen. No Android types: unit-testable on the JVM.
 * Actions are only added at the current boundary (after the groups completed so far),
 * in insertion order, using the existing schema 3 action model.
 */
object RecordingActionRules {
    const val MAX_WAIT_MS = 60_000L
    private val PACKAGE_REGEX = Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+")
    private val ID_REGEX = Regex("[A-Za-z0-9_-]{1,80}")

    sealed class Outcome {
        data class Added(val actions: List<MacroFlowAction>) : Outcome()
        data class Rejected(val reason: String) : Outcome()
    }

    /** Same defaults the macro manager already uses. */
    fun defaultWaitMs(type: MacroActionType): Long = when (type) {
        MacroActionType.LAUNCH_APP -> 2_500L
        MacroActionType.GO_HOME -> 1_200L
        MacroActionType.GO_BACK -> 700L
        MacroActionType.GO_RECENTS -> 1_000L
        MacroActionType.OPEN_INTERNET_PANEL -> 8_000L
    }

    fun label(action: MacroFlowAction): String = when (action.type) {
        MacroActionType.LAUNCH_APP -> "بازکردن ${action.appLabel}"
        MacroActionType.GO_HOME -> "رفتن به صفحه اصلی گوشی"
        MacroActionType.GO_BACK -> "بازگشت به صفحه قبلی"
        MacroActionType.GO_RECENTS -> "بازکردن برنامه‌های اخیر"
        MacroActionType.OPEN_INTERNET_PANEL -> "بازکردن پنل اینترنت"
    }

    /**
     * Validates [action] against the same limits MacroStore enforces on save, so a bad
     * action is rejected immediately instead of failing after a long recording.
     * [completedGroups] is the number of complete touch groups recorded so far;
     * [elapsedMs] is the recording clock now.
     */
    fun tryAdd(
        existing: List<MacroFlowAction>,
        action: MacroFlowAction,
        elapsedMs: Long,
        completedGroups: Int
    ): Outcome {
        if (completedGroups < 0 || action.afterGroupCount != completedGroups) {
            return Outcome.Rejected("اقدام فقط در محل فعلی ضبط و بین دو بخش کامل لمس اضافه می‌شود.")
        }
        if (existing.size >= MacroStore.MAX_ACTIONS) {
            return Outcome.Rejected("تعداد اقدامات به سقف مجاز رسیده است.")
        }
        if (!action.id.matches(ID_REGEX) || existing.any { it.id == action.id }) {
            return Outcome.Rejected("شناسه اقدام نامعتبر یا تکراری است.")
        }
        if (action.waitAfterMs !in 0L..MAX_WAIT_MS) {
            return Outcome.Rejected("مدت مکث پس از اقدام نامعتبر است.")
        }
        when (action.type) {
            MacroActionType.LAUNCH_APP -> {
                if (!action.packageName.matches(PACKAGE_REGEX) || action.appLabel.trim().length !in 1..100) {
                    return Outcome.Rejected("برنامهٔ انتخاب‌شده معتبر نیست.")
                }
            }
            MacroActionType.GO_HOME,
            MacroActionType.GO_BACK,
            MacroActionType.GO_RECENTS,
            MacroActionType.OPEN_INTERNET_PANEL -> {
                if (action.packageName.isNotEmpty() || action.appLabel.isNotEmpty()) {
                    return Outcome.Rejected("اقدام ناوبری نباید اطلاعات برنامه داشته باشد.")
                }
            }
        }
        val used = elapsedMs.coerceAtLeast(0L) + existing.sumOf { it.waitAfterMs } + action.waitAfterMs
        if (used > MacroStore.MAX_MACRO_DURATION_MS) {
            return Outcome.Rejected("مدت حرکت‌ها به‌همراه مکث‌های خودکار نباید از ۱۰ دقیقه بیشتر شود.")
        }
        return Outcome.Added(existing + action)
    }
}
