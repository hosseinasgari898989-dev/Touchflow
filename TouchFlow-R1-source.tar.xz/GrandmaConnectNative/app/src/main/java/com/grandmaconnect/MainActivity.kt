package com.grandmaconnect

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.util.DisplayMetrics
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private companion object {
        const val REQ_EXPORT = 51
        const val REQ_IMPORT = 52
    }


    private var homeStatus: TextView? = null
    private var currentPage = "home"
    private var orientationBeforeRecording: Int? = null
    private var recordingCanvas: TouchCanvasView? = null
    private var capturedGroups: List<MacroGestureGroup> = emptyList()
    private var pendingRecordingActions: List<MacroFlowAction> = emptyList()
    private var capturedDuration: Long = 1L
    private var capturedScreen: Pair<Int, Int> = 1080 to 2400

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        handleWidgetHelpIntent(intent)
    }

    private fun handleWidgetHelpIntent(source: Intent?) {
        val helpIntent = source ?: return
        if (helpIntent.action != MacroWidgetContract.ACTION_HELP) return
        val message = helpIntent.getStringExtra(MacroWidgetContract.EXTRA_MESSAGE).orEmpty()
        if (message.isBlank()) return
        val needsAccessibility = helpIntent.getBooleanExtra(MacroWidgetContract.EXTRA_NEEDS_ACCESSIBILITY, false)
        val needsNotifications = helpIntent.getBooleanExtra(MacroWidgetContract.EXTRA_NEEDS_NOTIFICATIONS, false)
        AlertDialog.Builder(this)
            .setTitle("اجرای ویجت نیاز به تنظیم دارد")
            .setMessage(message)
            .setNegativeButton("بعداً", null)
            .setPositiveButton(if (needsAccessibility || needsNotifications) "رفتن به تنظیمات" else "متوجه شدم") { _, _ ->
                when {
                    needsNotifications && Build.VERSION.SDK_INT >= 33 -> requestPermissions(
                        arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41
                    )
                    needsAccessibility -> openAccessibilitySettings()
                }
            }
            .show()
    }

    override fun onResume() {
        super.onResume()
        if (currentPage == "home") refreshHomeStatus()
    }

    override fun onDestroy() {
        restoreRecordingOrientation()
        setNormalSystemBars()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (currentPage == "record") {
            val canvas = recordingCanvas
            if (canvas?.isRecording() == true) {
                AlertDialog.Builder(this)
                    .setTitle("خروج از ضبط؟")
                    .setMessage("ضبط متوقف و حرکت‌های ذخیره‌نشده کنار گذاشته شوند؟")
                    .setNegativeButton("ادامه ضبط", null)
                    .setPositiveButton("خروج") { _, _ ->
                        canvas.stopRecording()
                        restoreRecordingOrientation()
                        setNormalSystemBars()
                        showHome()
                    }.show()
            } else {
                leaveRecorderConfirmingDiscard()
            }
            return
        }
        if (currentPage != "home") {
            showHome()
            return
        }
        super.onBackPressed()
    }

    // ---------------------------- Home ----------------------------

    private fun showHome() {
        currentPage = "home"
        val page = pageContainer()
        page.addView(title("TouchFlow", 30f))
        page.addView(body("ماکرو را انتخاب کن؛ اجرای آن با یک لمس شروع می‌شود."))

        val status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(38, 62, 86))
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(Color.rgb(231, 240, 250), 14)
        }
        homeStatus = status
        page.addView(status, matchWrap())
        refreshHomeStatus()
        status.setOnClickListener { openAccessibilitySettings() }

        page.addView(sectionTitle("برای اجرا، ماکرو را انتخاب کن"))
        val macros = MacroStore.loadAll(this)
        if (macros.isEmpty()) {
            val empty = TextView(this).apply {
                text = "هنوز ماکرویی ذخیره نشده است.\nبرای شروع، یک ماکرو ضبط کن."
                textSize = 16f
                setTextColor(Color.rgb(85, 95, 110))
                gravity = Gravity.CENTER
                setPadding(dp(18), dp(25), dp(18), dp(25))
                background = rounded(Color.WHITE, 16)
            }
            page.addView(empty, matchWrap())
        } else {
            macros.forEach { macro ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                    background = rounded(Color.WHITE, 16)
                    isClickable = true
                    isFocusable = true
                    setOnClickListener { requestOneTapPlayback(macro) }
                    contentDescription = "اجرای ماکرو ${macro.name}"
                }
                val macroName = TextView(this).apply {
                    text = macro.name
                    textSize = 20f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.rgb(28, 45, 66))
                }
                card.addView(macroName)
                card.addView(TextView(this).apply {
                    text = "برای اجرا یک‌بار اینجا بزن"
                    textSize = 15f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.rgb(35, 105, 180))
                    gravity = Gravity.CENTER
                    setPadding(0, dp(8), 0, dp(3))
                })

                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(12)
                page.addView(card, lp)
            }
        }

        page.addView(actionButton("مدیریت و ساخت ماکروها") { showToolsHome() })
        page.addView(body("برای اجرای سریع‌تر، ویجت TouchFlow را از فهرست ویجت‌های گوشی اضافه کن و ماکروی دلخواهت را به آن وصل کن."))
        page.addView(TextView(this).apply {
            text = "برای اجرای ماکرو فقط یک‌بار روی کارت آن بزن. هنگام اجرا، دکمه توقف در اعلان گوشی در دسترس است."
            textSize = 13f
            setTextColor(Color.rgb(105, 112, 124))
            setPadding(0, dp(12), 0, dp(12))
            gravity = Gravity.RIGHT
        })
        setContentView(scrollable(page))
        setNormalSystemBars()
    }

    private fun showToolsHome() {
        currentPage = "tools"
        val page = pageContainer()
        page.addView(title("مدیریت TouchFlow", 25f))
        page.addView(body("ابزارهای ساخت و تنظیم فقط در این بخش قرار دارند."))
        page.addView(actionButton("＋ ضبط ماکرو جدید") { showRecorder() })
        page.addView(actionButton("مدیریت مراحل و برنامه‌های ماکرو") { showMacroManagement() })
        page.addView(actionButton("تنظیمات ضبط") { showSettings() })
        page.addView(actionButton("بازگشت به اجرا") { showHome() })
        setContentView(scrollable(page))
    }

    private fun refreshHomeStatus() {
        val enabled = MacroAccessibilityService.isEnabledInSettings(this)
        val ready = MacroAccessibilityService.instance != null
        homeStatus?.text = when {
            enabled && ready -> "● سرویس اجرا آماده است — برای شروع، ماکرو را انتخاب کن"
            enabled -> "● مجوز روشن است؛ سرویس هنوز متصل نشده. برنامه را دوباره باز کن."
            else -> "○ برای اجرای ماکرو، یک‌بار مجوز دسترس‌پذیری را فعال کن"
        }
    }

    private fun openAccessibilitySettings() {
        AlertDialog.Builder(this)
            .setTitle("فعال‌سازی اجرای ماکرو")
            .setMessage("برای اجرای لمس‌های ضبط‌شده در برنامه‌های دیگر، سرویس TouchFlow باید در تنظیمات دسترس‌پذیری روشن شود. برنامه محتوای صفحه را نمی‌خواند.")
            .setNegativeButton("بعداً", null)
            .setPositiveButton("رفتن به تنظیمات") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (_: Exception) {
                    toast("تنظیمات دسترس‌پذیری باز نشد.")
                }
            }.show()
    }

    private fun requestOneTapPlayback(macro: TouchMacro) {
        try {
            MacroStore.validate(macro)
        } catch (error: Exception) {
            toast("این ماکرو قابل اجرا نیست: ${error.message ?: "اطلاعات نامعتبر"}")
            return
        }

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val recordedPortrait = macro.recordedScreenHeight >= macro.recordedScreenWidth
        val currentPortrait = metrics.heightPixels >= metrics.widthPixels
        if (recordedPortrait != currentPortrait) {
            toast("جهت صفحه با زمان ضبط فرق دارد. گوشی را به همان حالت برگردان.")
            return
        }

        if (!MacroAccessibilityService.isEnabledInSettings(this)) {
            openAccessibilitySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this)
                .setTitle("اجازه اعلان توقف")
                .setMessage("برای اینکه هنگام اجرای ماکرو بتوانی آن را متوقف کنی، اجازه اعلان لازم است.")
                .setNegativeButton("لغو", null)
                .setPositiveButton("فعال‌کردن") { _, _ -> requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41) }
                .show()
            return
        }
        val service = MacroAccessibilityService.instance
        if (service == null) {
            toast("سرویس هنوز آماده نشده؛ یک‌بار برنامه را ببند و دوباره باز کن.")
            return
        }
        try {
            service.playMacro(macro, initialDelayMs = 3_000L)
            toast("ماکرو شروع شد؛ توقف از اعلان در دسترس است.")
            finishAndRemoveTask()
        } catch (error: Exception) {
            toast("اجرای ماکرو شروع نشد: ${error.message ?: "خطای نامشخص"}")
        }
    }

    private fun showMacroManagement() {
        currentPage = "manage"
        val page = pageContainer()
        page.addView(title("مدیریت ماکروها", 25f))
        page.addView(body("اینجا می‌توانی مراحل خودکار را اضافه یا حذف کنی. برای اجرای ماکرو به صفحه اصلی برگرد."))
        val libraryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        libraryRow.addView(actionButton("پشتیبان‌گیری از همه") {
            val text = try { MacroStore.exportAll(this) } catch (error: Exception) { null }
            if (text == null || MacroStore.loadAll(this).isEmpty()) toast("ماکرویی برای پشتیبان‌گیری وجود ندارد.")
            else startExport("touchflow-backup.json", text)
        }, weightedButton())
        libraryRow.addView(actionButton("وارد کردن / بازیابی") { startImport() }, weightedButton())
        page.addView(libraryRow)
        val macros = MacroStore.loadAll(this)
        if (macros.isEmpty()) {
            page.addView(body("هنوز ماکرویی برای مدیریت وجود ندارد."))
        } else {
            val search = EditText(this).apply {
                hint = "جستجوی ماکرو (نام یا برنامهٔ داخل ماکرو)"
                setSingleLine()
            }
            val listBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            fun render(query: String) {
                listBox.removeAllViews()
                val shown = macros.filter { m ->
                    SearchRules.matches(query, m.name, *m.actions.map { it.appLabel }.toTypedArray())
                }
                if (shown.isEmpty()) {
                    listBox.addView(body("ماکرویی با این جستجو پیدا نشد."))
                    return
                }
                shown.forEach { macro ->
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutDirection = View.LAYOUT_DIRECTION_RTL
                        setPadding(dp(14), dp(10), dp(14), dp(10))
                        background = rounded(Color.WHITE, 14)
                    }
                    card.addView(title(macro.name, 18f))
                    card.addView(body("${macro.groups.size} بخش لمس · ${macro.actions.size} اقدام خودکار"))
                    val row = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        layoutDirection = View.LAYOUT_DIRECTION_RTL
                    }
                    row.addView(actionButton("مدیریت مراحل") { showMacroActions(macro.id) }, weightedButton())
                    row.addView(actionButton("حذف") { confirmDelete(macro) }, weightedButton())
                    card.addView(row)
                    card.addView(actionButton("ویرایش برش‌های زمانی") { showMacroTimeline(macro.id) })
                    val libraryOps = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        layoutDirection = View.LAYOUT_DIRECTION_RTL
                    }
                    libraryOps.addView(actionButton("تغییر نام") { promptRename(macro) }, weightedButton())
                    libraryOps.addView(actionButton("تکثیر") {
                        try {
                            MacroStore.duplicate(this, macro.id)
                            toast("ماکرو تکثیر شد.")
                            showMacroManagement()
                        } catch (error: Exception) {
                            toast("تکثیر انجام نشد: ${error.message ?: "خطای نامشخص"}")
                        }
                    }, weightedButton())
                    libraryOps.addView(actionButton("صدور") {
                        try {
                            startExport(MacroNaming.fileName(macro.name), MacroStore.exportMacro(macro))
                        } catch (error: Exception) {
                            toast("صدور انجام نشد: ${error.message ?: "خطای نامشخص"}")
                        }
                    }, weightedButton())
                    card.addView(libraryOps)
                    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.bottomMargin = dp(10)
                    listBox.addView(card, lp)
                }
            }
            search.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: android.text.Editable?) = render(s?.toString().orEmpty())
            })
            page.addView(search)
            page.addView(listBox)
            render("")
        }
        page.addView(actionButton("بازگشت") { showHome() })
        setContentView(scrollable(page))
    }

    private fun showMacroTimeline(macroId: String) {
        currentPage = "timeline"
        val macro = MacroStore.loadAll(this).firstOrNull { it.id == macroId }
        if (macro == null) {
            toast("ماکرو پیدا نشد.")
            showMacroManagement()
            return
        }
        val page = pageContainer()
        page.addView(title("ویرایش زمانی: ${macro.name}", 23f))
        page.addView(body("Split فقط ماکرو را به بخش‌های نمایشی تقسیم می‌کند؛ هیچ لمس، زمان یا اقدامی حذف و جابه‌جا نمی‌شود."))
        page.addView(body("برای برش، دکمه را بین دو بخش لمس بزن. برش وسط یک لمس چندانگشتی مجاز نیست."))

        macro.groups.forEachIndexed { index, group ->
            val endMs = group.startOffsetMs + (group.strokes.maxOfOrNull { it.startOffsetMs + it.durationMs } ?: 0L)
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(12), dp(9), dp(12), dp(9))
                background = rounded(Color.WHITE, 13)
            }
            card.addView(title("بخش لمس ${index + 1}", 16f))
            card.addView(body("شروع: ${formatTimelineTime(group.startOffsetMs)} · پایان: ${formatTimelineTime(endMs)} · ${group.strokes.size} لمس هم‌زمان"))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(5)
            page.addView(card, lp)

            if (index < macro.groups.lastIndex) {
                val boundary = index + 1
                val isSplit = boundary in macro.splitAfterGroupCounts
                val markerText = if (isSplit) "حذف Split بین بخش ${boundary} و ${boundary + 1}" else "＋ Split بعد از بخش $boundary"
                page.addView(actionButton(markerText) {
                    try {
                        val updatedMarkers = if (isSplit) {
                            MacroSplitRules.remove(macro.splitAfterGroupCounts, macro.groups.size, boundary)
                        } else {
                            MacroSplitRules.add(macro.splitAfterGroupCounts, macro.groups.size, boundary)
                        }
                        MacroStore.save(this, macro.copy(splitAfterGroupCounts = updatedMarkers))
                        showMacroTimeline(macro.id)
                    } catch (error: Exception) {
                        toast("ویرایش Split انجام نشد: ${error.message ?: "خطای نامشخص"}")
                    }
                })
                if (isSplit) page.addView(body("— مرز برش ذخیره‌شده —"))
            }
        }
        page.addView(actionButton("بازگشت به مدیریت ماکرو") { showMacroManagement() })
        setContentView(scrollable(page))
    }

    private fun formatTimelineTime(milliseconds: Long): String {
        val totalSeconds = milliseconds.coerceAtLeast(0L) / 1000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        val centiseconds = (milliseconds.coerceAtLeast(0L) % 1000L) / 10L
        return "%02d:%02d.%02d".format(minutes, seconds, centiseconds)
    }

    private fun promptRename(macro: TouchMacro) {
        val input = EditText(this).apply {
            setText(macro.name)
            setSingleLine()
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("تغییر نام ماکرو")
            .setView(input)
            .setNegativeButton("لغو", null)
            .setPositiveButton("ذخیره") { _, _ ->
                try {
                    MacroStore.rename(this, macro.id, input.text.toString())
                    showMacroManagement()
                } catch (error: Exception) {
                    toast("تغییر نام انجام نشد: ${error.message ?: "خطای نامشخص"}")
                }
            }
            .show()
    }

    // ---------------------------- Export / import (system file picker; no storage permission) ----------------------------

    private var pendingExportText: String? = null

    private fun startExport(fileName: String, text: String) {
        pendingExportText = text
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, fileName)
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_EXPORT)
        } catch (error: Exception) {
            pendingExportText = null
            toast("انتخاب محل ذخیره در این گوشی ممکن نشد.")
        }
    }

    private fun startImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain", "application/octet-stream"))
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_IMPORT)
        } catch (error: Exception) {
            toast("انتخاب فایل در این گوشی ممکن نشد.")
        }
    }

    private fun readImportText(uri: android.net.Uri): String {
        val stream = contentResolver.openInputStream(uri) ?: throw IllegalStateException("فایل باز نشد.")
        stream.use { input ->
            val bytes = input.readNBytesCompat(MacroStore.MAX_IMPORT_BYTES + 1)
            require(bytes.size <= MacroStore.MAX_IMPORT_BYTES) { "فایل بیش از حد بزرگ است." }
            return String(bytes, Charsets.UTF_8)
        }
    }

    private fun java.io.InputStream.readNBytesCompat(limit: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        while (out.size() < limit) {
            val read = read(buffer, 0, minOf(buffer.size, limit - out.size()))
            if (read < 0) break
            out.write(buffer, 0, read)
        }
        return out.toByteArray()
    }

    @Deprecated("Uses the classic Activity result API.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_EXPORT && requestCode != REQ_IMPORT) return
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) {
            if (requestCode == REQ_EXPORT) pendingExportText = null
            return
        }
        if (requestCode == REQ_EXPORT) {
            val text = pendingExportText
            pendingExportText = null
            if (text == null) {
                toast("خروجی آماده نبود؛ دوباره امتحان کن.")
                return
            }
            try {
                val out = contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("فایل مقصد باز نشد.")
                out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                toast("فایل ذخیره شد.")
            } catch (error: Exception) {
                toast("ذخیرهٔ فایل انجام نشد: ${error.message ?: "خطای نامشخص"}")
            }
        } else {
            try {
                val macros = MacroStore.parseImported(readImportText(uri))
                MacroStore.importMacros(this, macros)
                toast("${macros.size} ماکرو وارد شد.")
                showMacroManagement()
            } catch (error: Exception) {
                toast("وارد کردن انجام نشد: ${error.message ?: "فایل نامعتبر"}")
            }
        }
    }

    private fun confirmDelete(macro: TouchMacro) {
        AlertDialog.Builder(this)
            .setTitle("حذف ماکرو")
            .setMessage("ماکرو «${macro.name}» حذف شود؟")
            .setNegativeButton("لغو", null)
            .setPositiveButton("حذف") { _, _ ->
                MacroStore.delete(this, macro.id)
                showHome()
            }.show()
    }

    // ---------------------------- Full-screen recorder ----------------------------

    private fun showRecorder() {
        currentPage = "record"
        lockOrientationForRecording()
        setImmersiveSystemBars()
        capturedGroups = emptyList()
        pendingRecordingActions = emptyList()
        capturedDuration = 1L

        val frame = FrameLayout(this).apply { setBackgroundColor(Color.rgb(250, 251, 253)) }
        val canvas = TouchCanvasView(this)
        recordingCanvas = canvas
        frame.addView(canvas, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val topName = EditText(this).apply {
            hint = "نام ماکرو"
            setText("ماکرو جدید")
            textSize = 17f
            setSingleLine(true)
            setTextColor(Color.rgb(25, 40, 60))
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = rounded(Color.WHITE, 12)
        }
        val status = TextView(this).apply {
            text = "برای شروع، دکمه پایین را بزن. تمام صفحه در اختیار ضبط است."
            textSize = 13f
            setTextColor(Color.rgb(35, 50, 68))
            setPadding(dp(8), dp(5), dp(8), dp(5))
            background = rounded(Color.argb(225, 255, 255, 255), 10)
            isClickable = false
            isFocusable = false
        }

        val startButton = actionButton("شروع ضبط") { }
        val backButton = actionButton("بازگشت") { showHomeFromRecorder(canvas) }
        val saveButton = actionButton("ذخیره ماکرو") { }
        val restartButton = actionButton("ضبط دوباره") { }
        saveButton.isEnabled = false
        restartButton.visibility = View.GONE

        val topPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10), dp(8), dp(10), dp(5))
            background = rounded(Color.argb(218, 245, 248, 252), 14)
            addView(topName, matchWrap())
            addView(status, matchWrap())
        }
        val topLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP)
            .apply { leftMargin = dp(8); rightMargin = dp(8); topMargin = dp(8) }
        frame.addView(topPanel, topLp)

        val bottomPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = rounded(Color.argb(232, 245, 248, 252), 16)
            addView(startButton, weightedButton())
            addView(saveButton, weightedButton())
            addView(restartButton, weightedButton())
            addView(backButton, weightedButton())
        }
        val bottomLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
            .apply { leftMargin = dp(8); rightMargin = dp(8); bottomMargin = dp(8) }
        frame.addView(bottomPanel, bottomLp)

        val addAppFloating = actionButton("＋ اقدام") { }
        addAppFloating.visibility = View.GONE
        val addAppLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START)
            .apply { leftMargin = dp(14); bottomMargin = dp(18) }
        frame.addView(addAppFloating, addAppLp)

        val stopFloating = actionButton("■ توقف") { }
        stopFloating.visibility = View.GONE
        val floatingLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
            .apply { rightMargin = dp(14); bottomMargin = dp(18) }
        frame.addView(stopFloating, floatingLp)

        val pauseFloating = actionButton("⏸ مکث") { }
        pauseFloating.visibility = View.GONE
        val pauseLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            .apply { bottomMargin = dp(18) }
        frame.addView(pauseFloating, pauseLp)

        fun showStoppedControls(message: String) {
            pauseFloating.visibility = View.GONE
            status.text = message
            topName.visibility = View.VISIBLE
            bottomPanel.visibility = View.VISIBLE
            startButton.visibility = View.GONE
                restartButton.visibility = View.VISIBLE
            saveButton.visibility = if (capturedGroups.isNotEmpty()) View.VISIBLE else View.GONE
            saveButton.isEnabled = capturedGroups.isNotEmpty()
            stopFloating.visibility = View.GONE
            addAppFloating.visibility = View.GONE
        }

        startButton.setOnClickListener {
            val name = topName.text?.toString()?.trim().orEmpty()
            if (name.isBlank() || name.length > 40) {
                toast("نام ماکرو باید بین ۱ تا ۴۰ نویسه باشد.")
                return@setOnClickListener
            }
            val profile = MacroSettingsStore.load(this)
            canvas.startRecording(profile)
            status.text = "● در حال ضبط — هر نقطه‌ای از صفحه را لمس و حرکت بده"
            topName.visibility = View.GONE
            bottomPanel.visibility = View.GONE
            stopFloating.visibility = View.VISIBLE
            addAppFloating.visibility = View.VISIBLE
            pauseFloating.text = "⏸ مکث"
            pauseFloating.visibility = View.VISIBLE
        }

        pauseFloating.setOnClickListener {
            if (canvas.isPaused()) {
                if (canvas.resumeRecording()) {
                    pauseFloating.text = "⏸ مکث"
                    status.text = "● ضبط ادامه یافت — لمس‌های بعدی ثبت می‌شوند"
                }
            } else if (canvas.pauseRecording()) {
                pauseFloating.text = "▶ ادامه"
                status.text = "⏸ ضبط مکث شد؛ زمان مکث در ماکرو ثبت نمی‌شود و لمس‌ها ضبط نمی‌شوند"
            } else {
                toast("برای مکث، ابتدا انگشتت را از صفحه بردار و لمس جاری را کامل کن.")
            }
        }

        fun addRecordingAction(
            boundary: Int,
            type: MacroActionType,
            app: AppPicker.App? = null,
            waitMs: Long = RecordingActionRules.defaultWaitMs(type)
        ) {
            if (!canvas.isRecording() || !canvas.canInsertFlowAction() || canvas.completedGroupCount() != boundary) {
                toast("ضبط در این فاصله تغییر کرده؛ اقدام اضافه نشد.")
                return
            }
            val action = MacroFlowAction(
                id = MacroStore.newId(),
                afterGroupCount = boundary,
                type = type,
                packageName = app?.packageName.orEmpty(),
                appLabel = app?.label.orEmpty(),
                waitAfterMs = waitMs
            )
            when (val outcome = RecordingActionRules.tryAdd(pendingRecordingActions, action, canvas.elapsedMs(), boundary)) {
                is RecordingActionRules.Outcome.Added -> {
                    pendingRecordingActions = outcome.actions
                    status.text = "اقدام «${RecordingActionRules.label(action)}» بعد از بخش ${boundary} ذخیره شد؛ برای ضبط حرکت بعدی ادامه بده."
                }
                is RecordingActionRules.Outcome.Rejected -> toast(outcome.reason)
            }
        }

        addAppFloating.setOnClickListener {
            if (!canvas.canInsertFlowAction()) {
                toast("برای افزودن اقدام، ابتدا لمس فعلی را کامل کن و انگشتت را از صفحه بردار.")
                return@setOnClickListener
            }
            val boundary = canvas.completedGroupCount()
            val labels = arrayOf(
                "بازکردن برنامه",
                "رفتن به صفحه اصلی گوشی",
                "بازگشت اندروید (Back)",
                "برنامه‌های اخیر (Recents)",
                "پنل اینترنت"
            )
            AlertDialog.Builder(this)
                .setTitle("افزودن اقدام به ادامه ماکرو")
                .setItems(labels) { _, which ->
                    when (which) {
                        0 -> AppPicker.show(this, "افزودن برنامه به ادامه ماکرو") { app ->
                            chooseActionDelay { delay ->
                                addRecordingAction(boundary, MacroActionType.LAUNCH_APP, app, delay)
                            }
                        }
                        1 -> addRecordingAction(boundary, MacroActionType.GO_HOME)
                        2 -> addRecordingAction(boundary, MacroActionType.GO_BACK)
                        3 -> addRecordingAction(boundary, MacroActionType.GO_RECENTS)
                        4 -> AlertDialog.Builder(this)
                            .setTitle("پنل اینترنت")
                            .setMessage("اندروید به برنامه‌های عادی اجازهٔ روشن/خاموش‌کردن بی‌صدای وای‌فای یا دادهٔ همراه را نمی‌دهد. این اقدام فقط پنل رسمی اینترنت را باز می‌کند و تغییر را خودت انجام می‌دهی؛ ماکرو ۸ ثانیه صبر می‌کند.")
                            .setNegativeButton("لغو", null)
                            .setPositiveButton("ادامه") { _, _ ->
                                addRecordingAction(boundary, MacroActionType.OPEN_INTERNET_PANEL)
                            }
                            .show()
                        else -> Unit
                    }
                }
                .setNegativeButton("لغو", null)
                .show()
        }

        stopFloating.setOnClickListener { finishRecording(canvas, ::showStoppedControls) }

        restartButton.setOnClickListener {
            capturedGroups = emptyList()
            pendingRecordingActions = emptyList()
            capturedDuration = 1L
            canvas.startRecording(MacroSettingsStore.load(this))
            status.text = "● در حال ضبط — برای افزودن اقدام (برنامه، Home، Back، Recents، پنل اینترنت) از دکمه شناور سمت چپ استفاده کن"
            topName.visibility = View.GONE
            bottomPanel.visibility = View.GONE
            stopFloating.visibility = View.VISIBLE
            addAppFloating.visibility = View.VISIBLE
            pauseFloating.text = "⏸ مکث"
            pauseFloating.visibility = View.VISIBLE
        }

        saveButton.setOnClickListener {
            val name = topName.text?.toString()?.trim().orEmpty().ifBlank { "ماکرو جدید" }
            if (name.length > 40) {
                toast("نام ماکرو نباید بیشتر از ۴۰ نویسه باشد.")
                return@setOnClickListener
            }
            try {
                val macro = TouchMacro(
                    id = MacroStore.newId(),
                    name = name,
                    createdAt = System.currentTimeMillis(),
                    recordedScreenWidth = capturedScreen.first,
                    recordedScreenHeight = capturedScreen.second,
                    totalDurationMs = capturedDuration.coerceIn(1L, MacroHardLimits.MAX_MACRO_DURATION_MS),
                    groups = capturedGroups,
                    actions = pendingRecordingActions
                )
                MacroStore.save(this, macro)
                restoreRecordingOrientation()
                setNormalSystemBars()
                toast("ماکرو ذخیره شد.")
                showHome()
            } catch (error: Exception) {
                toast("ذخیره انجام نشد: ${error.message ?: "خطای نامشخص"}")
            }
        }

        backButton.setOnClickListener { showHomeFromRecorder(canvas) }
        canvas.onLimitReached = { reason ->
            capturedGroups = canvas.stopRecording()
            capturedDuration = canvas.elapsedMs().coerceIn(1L, MacroHardLimits.MAX_MACRO_DURATION_MS)
            capturedScreen = canvas.currentScreenSize()
            showStoppedControls("$reason · ${capturedGroups.size} بخش لمس ثبت شد")
        }
        setContentView(frame)
        frame.post { if (currentPage == "record") setImmersiveSystemBars() }
    }

    private fun finishRecording(canvas: TouchCanvasView, updateUi: (String) -> Unit) {
        if (!canvas.isRecording()) return
        val elapsed = canvas.elapsedMs().coerceAtLeast(1L)
        capturedGroups = canvas.stopRecording()
        capturedDuration = elapsed.coerceAtMost(MacroHardLimits.MAX_MACRO_DURATION_MS)
        capturedScreen = canvas.currentScreenSize()
        updateUi(if (capturedGroups.isEmpty()) "حرکتی ضبط نشد؛ دوباره امتحان کن." else "${capturedGroups.size} بخش لمس ثبت شد. می‌توانی ذخیره کنی یا دوباره ضبط کنی.")
    }

    private fun showHomeFromRecorder(canvas: TouchCanvasView) {
        if (canvas.isRecording()) {
            AlertDialog.Builder(this)
                .setTitle("لغو ضبط؟")
                .setMessage("ضبط متوقف و اطلاعات ذخیره‌نشده کنار گذاشته شود؟")
                .setNegativeButton("ادامه ضبط", null)
                .setPositiveButton("لغو ضبط") { _, _ ->
                    canvas.stopRecording()
                    restoreRecordingOrientation()
                    setNormalSystemBars()
                    showHome()
                }.show()
        } else {
            leaveRecorderConfirmingDiscard()
        }
    }

    /** Leaving after a stopped recording would silently lose it, so ask first when it has content. */
    private fun leaveRecorderConfirmingDiscard() {
        val leave = {
            restoreRecordingOrientation()
            setNormalSystemBars()
            showHome()
        }
        if (capturedGroups.isEmpty()) {
            leave()
        } else {
            AlertDialog.Builder(this)
                .setTitle("دور انداختن ضبط؟")
                .setMessage("این ضبط هنوز ذخیره نشده و با خروج از بین می‌رود.")
                .setNegativeButton("ماندن", null)
                .setPositiveButton("دور انداختن") { _, _ -> leave() }
                .show()
        }
    }

    private fun lockOrientationForRecording() {
        if (orientationBeforeRecording == null) {
            orientationBeforeRecording = requestedOrientation
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
        }
    }

    private fun restoreRecordingOrientation() {
        val previous = orientationBeforeRecording ?: return
        orientationBeforeRecording = null
        requestedOrientation = previous
        recordingCanvas = null
    }

    private var previousCutoutMode: Int? = null

    private fun setImmersiveSystemBars() {
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 28) {
            val attributes = window.attributes
            if (previousCutoutMode == null) previousCutoutMode = attributes.layoutInDisplayCutoutMode
            attributes.layoutInDisplayCutoutMode =
                android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = attributes
        }
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { controller ->
                controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsets.Type.systemBars())
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        }
    }

    private fun setNormalSystemBars() {
        if (Build.VERSION.SDK_INT >= 28) {
            previousCutoutMode?.let { oldMode ->
                val attributes = window.attributes
                attributes.layoutInDisplayCutoutMode = oldMode
                window.attributes = attributes
            }
            previousCutoutMode = null
        }
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.show(WindowInsets.Type.systemBars())
        }
        window.statusBarColor = Color.rgb(245, 247, 250)
        window.navigationBarColor = Color.rgb(245, 247, 250)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
    }

    // ---------------------------- Macro actions ----------------------------

    private fun showMacroActions(macroId: String) {
        currentPage = "actions"
        val macro = MacroStore.loadAll(this).firstOrNull { it.id == macroId }
        if (macro == null) {
            toast("ماکرو پیدا نشد.")
            showHome()
            return
        }
        val page = pageContainer()
        page.addView(title("مراحل: ${macro.name}", 24f))
        page.addView(body("می‌توانی بعد از هر بخش لمس، یک برنامه باز کنی یا به صفحه اصلی برگردی. سپس ماکرو پس از مکث ادامه می‌دهد."))
        if (macro.actions.isEmpty()) {
            page.addView(body("هنوز اقدام خودکاری اضافه نشده است."))
        } else {
            macro.actions.forEach { action ->
                val label = when (action.type) {
                    MacroActionType.LAUNCH_APP -> "بازکردن ${action.appLabel}"
                    MacroActionType.GO_HOME -> "رفتن به صفحه اصلی گوشی"
                    MacroActionType.GO_BACK -> "بازگشت به صفحه قبلی"
                    MacroActionType.GO_RECENTS -> "بازکردن برنامه‌های اخیر"
                    MacroActionType.OPEN_INTERNET_PANEL -> "بازکردن پنل اینترنت (تغییر با خود کاربر)"
                }
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setPadding(dp(10), dp(9), dp(10), dp(9))
                    background = rounded(Color.WHITE, 12)
                }
                card.addView(TextView(this).apply {
                    text = "پس از ${action.afterGroupCount} بخش لمس\n$label · مکث ${action.waitAfterMs / 1000.0} ثانیه"
                    textSize = 15f
                    setTextColor(Color.rgb(40, 52, 68))
                    setPadding(dp(6), 0, dp(6), 0)
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                card.addView(actionButton("حذف") {
                    AlertDialog.Builder(this)
                        .setMessage("این اقدام از ماکرو حذف شود؟")
                        .setNegativeButton("لغو", null)
                        .setPositiveButton("حذف") { _, _ ->
                            MacroStore.save(this, macro.copy(actions = macro.actions.filterNot { it.id == action.id }))
                            showMacroActions(macro.id)
                        }.show()
                })
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(8)
                page.addView(card, lp)
            }
        }

        page.addView(actionButton("＋ افزودن بازکردن برنامه") {
            chooseActionBoundary(macro) { boundary -> chooseLaunchApp(macro, boundary) }
        })
        page.addView(actionButton("＋ افزودن رفتن به صفحه اصلی") {
            chooseActionBoundary(macro) { boundary ->
                val action = MacroFlowAction(
                    id = MacroStore.newId(),
                    afterGroupCount = boundary,
                    type = MacroActionType.GO_HOME,
                    waitAfterMs = 1_200L
                )
                saveActionAndRefresh(macro, action)
            }
        })
        page.addView(actionButton("＋ افزودن دکمه بازگشت اندروید") {
            chooseActionBoundary(macro) { boundary ->
                val action = MacroFlowAction(
                    id = MacroStore.newId(),
                    afterGroupCount = boundary,
                    type = MacroActionType.GO_BACK,
                    waitAfterMs = 700L
                )
                saveActionAndRefresh(macro, action)
            }
        })
        page.addView(actionButton("＋ افزودن برنامه‌های اخیر") {
            chooseActionBoundary(macro) { boundary ->
                saveActionAndRefresh(macro, MacroFlowAction(
                    id = MacroStore.newId(),
                    afterGroupCount = boundary,
                    type = MacroActionType.GO_RECENTS,
                    waitAfterMs = 1_000L
                ))
            }
        })
        page.addView(actionButton("＋ افزودن پنل اینترنت") {
            AlertDialog.Builder(this)
                .setTitle("پنل اینترنت")
                .setMessage("اندروید به برنامه‌های عادی اجازهٔ روشن/خاموش‌کردن بی‌صدای وای‌فای یا دادهٔ همراه را نمی‌دهد. این اقدام فقط پنل رسمی اینترنت را باز می‌کند و تغییر را خودت انجام می‌دهی؛ ماکرو ۸ ثانیه صبر می‌کند.")
                .setNegativeButton("لغو", null)
                .setPositiveButton("ادامه") { _, _ ->
                    chooseActionBoundary(macro) { boundary ->
                        saveActionAndRefresh(macro, MacroFlowAction(
                            id = MacroStore.newId(),
                            afterGroupCount = boundary,
                            type = MacroActionType.OPEN_INTERNET_PANEL,
                            waitAfterMs = 8_000L
                        ))
                    }
                }.show()
        })
        page.addView(actionButton("بازگشت") { showHome() })
        setContentView(scrollable(page))
    }

    private fun chooseActionBoundary(macro: TouchMacro, onChosen: (Int) -> Unit) {
        val labels = Array(macro.groups.size + 1) { index ->
            if (index == 0) "قبل از اولین بخش لمس" else "بعد از بخش لمس شماره $index"
        }
        AlertDialog.Builder(this)
            .setTitle("این اقدام کجا اجرا شود؟")
            .setItems(labels) { _, which -> onChosen(which) }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun chooseLaunchApp(macro: TouchMacro, boundary: Int) {
        AppPicker.show(this, "انتخاب برنامه برای بازکردن") { app ->
            chooseActionDelay { delay ->
                val action = MacroFlowAction(
                    id = MacroStore.newId(),
                    afterGroupCount = boundary,
                    type = MacroActionType.LAUNCH_APP,
                    packageName = app.packageName,
                    appLabel = app.label,
                    waitAfterMs = delay
                )
                saveActionAndRefresh(macro, action)
            }
        }
    }

    private fun chooseActionDelay(onChosen: (Long) -> Unit) {
        val waits = longArrayOf(1_500L, 2_500L, 4_000L, 6_000L)
        val labels = arrayOf("۱٫۵ ثانیه", "۲٫۵ ثانیه — پیشنهاد ما", "۴ ثانیه", "۶ ثانیه")
        AlertDialog.Builder(this)
            .setTitle("مکث پس از بازکردن برنامه")
            .setSingleChoiceItems(labels, 1) { dialog, which ->
                dialog.dismiss()
                onChosen(waits[which])
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun saveActionAndRefresh(macro: TouchMacro, action: MacroFlowAction) {
        try {
            MacroStore.save(this, macro.copy(actions = macro.actions + action))
            toast("اقدام به ماکرو اضافه شد.")
            showMacroActions(macro.id)
        } catch (error: Exception) {
            toast("ذخیره اقدام انجام نشد: ${error.message ?: "خطای نامشخص"}")
        }
    }

    // ---------------------------- Capture settings ----------------------------

    private fun showSettings() {
        currentPage = "settings"
        val existing = MacroSettingsStore.load(this)
        val page = pageContainer()
        page.addView(title("تنظیمات ضبط", 25f))
        page.addView(body("این تنظیمات روی ضبط‌های بعدی اثر می‌گذارند؛ ماکروهای ذخیره‌شده تغییر نمی‌کنند."))

        val extendedSwitch = android.widget.Switch(this).apply {
            text = "افزایش ظرفیت ضبط"
            textSize = 17f
            isChecked = existing.extendedCapacity
            setPadding(0, dp(8), 0, dp(8))
        }
        page.addView(extendedSwitch, matchWrap())
        page.addView(body("با فعال‌سازی، زمان و تعداد نقاط بیشتری ضبط می‌شود. محدودیت‌های سخت اندروید و سقف ایمنی برنامه همچنان برقرارند."))

        page.addView(sectionTitle("حداکثر زمان یک ضبط"))
        val durationGroup = android.widget.RadioGroup(this).apply { orientation = android.widget.RadioGroup.VERTICAL }
        val durationIds = linkedMapOf<Int, Long>()
        val selectedDuration = existing.maxMacroDurationMs.takeIf { it in MacroSettingsStore.extendedDurationsMs } ?: 5 * 60 * 1000L
        MacroSettingsStore.extendedDurationsMs.forEach { duration ->
            val radio = android.widget.RadioButton(this).apply {
                id = View.generateViewId()
                text = MacroSettingsStore.describeDuration(duration)
                textSize = 16f
                isChecked = duration == selectedDuration
            }
            durationIds[radio.id] = duration
            durationGroup.addView(radio)
        }
        page.addView(durationGroup)
        extendedSwitch.setOnCheckedChangeListener { _, checked ->
            durationGroup.isEnabled = checked
            for (i in 0 until durationGroup.childCount) durationGroup.getChildAt(i).isEnabled = checked
        }
        durationGroup.isEnabled = existing.extendedCapacity
        for (i in 0 until durationGroup.childCount) durationGroup.getChildAt(i).isEnabled = existing.extendedCapacity

        page.addView(sectionTitle("کیفیت ثبت حرکت"))
        val qualityGroup = android.widget.RadioGroup(this).apply { orientation = android.widget.RadioGroup.VERTICAL }
        val qualityIds = linkedMapOf<Int, CaptureQuality>()
        CaptureQuality.values().forEach { quality ->
            val radio = android.widget.RadioButton(this).apply {
                id = View.generateViewId()
                text = when (quality) {
                    CaptureQuality.ECONOMY -> "اقتصادی — مصرف حافظه کمتر"
                    CaptureQuality.BALANCED -> "متعادل — پیشنهاد ما"
                    CaptureQuality.PRECISE -> "دقیق — نقاط بیشتر"
                }
                textSize = 16f
                isChecked = quality == CaptureQuality.fromKey(
                    getSharedPreferences("macro_capture_settings", MODE_PRIVATE)
                        .getString("capture_quality", CaptureQuality.BALANCED.key)
                )
            }
            qualityIds[radio.id] = quality
            qualityGroup.addView(radio)
        }
        page.addView(qualityGroup)

        page.addView(actionButton("ذخیره تنظیمات") {
            val duration = durationIds[durationGroup.checkedRadioButtonId] ?: 5 * 60 * 1000L
            val quality = qualityIds[qualityGroup.checkedRadioButtonId] ?: CaptureQuality.BALANCED
            try {
                MacroSettingsStore.save(this, extendedSwitch.isChecked, quality, duration)
                toast("تنظیمات ذخیره شد.")
                showHome()
            } catch (error: Exception) {
                toast("ذخیره تنظیمات ناموفق بود: ${error.message ?: "خطای نامشخص"}")
            }
        })
        page.addView(actionButton("بازگشت") { showHome() })
        setContentView(scrollable(page))
    }

    // ---------------------------- Small view helpers ----------------------------

    private fun pageContainer(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(18))
        setBackgroundColor(Color.rgb(245, 247, 250))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        isFocusableInTouchMode = true
    }

    @Suppress("DEPRECATION")
    private fun scrollable(child: View): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        clipToPadding = false
        overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        setOnApplyWindowInsetsListener { view, insets ->
            val top: Int
            val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                top = bars.top
                bottom = bars.bottom
            } else {
                top = insets.systemWindowInsetTop
                bottom = insets.systemWindowInsetBottom
            }
            view.setPadding(0, top, 0, bottom)
            insets
        }
        addView(child, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun title(text: String, size: Float): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        typeface = AppTypography.typeface(this@MainActivity, AppTypography.Weight.BOLD)
        setTextColor(Color.rgb(27, 43, 64))
        gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun sectionTitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 19f
        typeface = AppTypography.typeface(this@MainActivity, AppTypography.Weight.BOLD)
        setTextColor(Color.rgb(34, 53, 77))
        gravity = Gravity.RIGHT
        setPadding(0, dp(14), 0, dp(8))
    }

    private fun body(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        setTextColor(Color.rgb(79, 91, 107))
        gravity = Gravity.RIGHT
        setPadding(0, dp(5), 0, dp(7))
        setLineSpacing(dp(2).toFloat(), 1.0f)
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        typeface = AppTypography.typeface(this@MainActivity, AppTypography.Weight.MEDIUM)
        textSize = 15f
        isAllCaps = false
        minHeight = dp(50)
        setPadding(dp(9), dp(7), dp(9), dp(7))
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), Color.rgb(226, 231, 238))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun weightedButton() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
        marginEnd = dp(3)
        marginStart = dp(3)
    }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                toast("اجازه اعلان فعال شد؛ حالا ماکرو را انتخاب کن.")
            } else {
                toast("بدون اعلان توقف، اجرای ماکرو شروع نمی‌شود.")
            }
        }
    }
}
