package com.grandmaconnect

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RecordingActionRulesTest {
    private fun nav(id: String, boundary: Int, type: MacroActionType, wait: Long = RecordingActionRules.defaultWaitMs(type)) =
        MacroFlowAction(id = id, afterGroupCount = boundary, type = type, waitAfterMs = wait)

    private fun app(id: String, boundary: Int, pkg: String = "com.android.chrome", label: String = "Chrome") =
        MacroFlowAction(id = id, afterGroupCount = boundary, type = MacroActionType.LAUNCH_APP, packageName = pkg, appLabel = label, waitAfterMs = 2_500L)

    private fun rejected(o: RecordingActionRules.Outcome) = o is RecordingActionRules.Outcome.Rejected
    private fun added(o: RecordingActionRules.Outcome) = (o as RecordingActionRules.Outcome.Added).actions

    @Test fun acceptsAllFiveTypesAtCurrentBoundary() {
        var list = emptyList<MacroFlowAction>()
        val items = listOf(
            app("a1", 2),
            nav("a2", 2, MacroActionType.GO_HOME),
            nav("a3", 2, MacroActionType.GO_BACK),
            nav("a4", 2, MacroActionType.GO_RECENTS),
            nav("a5", 2, MacroActionType.OPEN_INTERNET_PANEL)
        )
        for (item in items) list = added(RecordingActionRules.tryAdd(list, item, 1_000L, 2))
        assertEquals(5, list.size)
    }

    @Test fun keepsInsertionOrderAtSameBoundaryAndAcrossBoundaries() {
        var list = emptyList<MacroFlowAction>()
        list = added(RecordingActionRules.tryAdd(list, nav("x1", 0, MacroActionType.GO_HOME), 0L, 0))
        list = added(RecordingActionRules.tryAdd(list, nav("x2", 0, MacroActionType.GO_BACK), 0L, 0))
        list = added(RecordingActionRules.tryAdd(list, nav("x3", 1, MacroActionType.GO_RECENTS), 500L, 1))
        assertEquals(listOf("x1", "x2", "x3"), list.map { it.id })
        // playback filters by boundary in list order
        assertEquals(listOf("x1", "x2"), list.filter { it.afterGroupCount == 0 }.map { it.id })
    }

    @Test fun rejectsWrongBoundary() {
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), nav("b1", 1, MacroActionType.GO_HOME), 0L, 2)))
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), nav("b2", 3, MacroActionType.GO_HOME), 0L, 2)))
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), nav("b3", -1, MacroActionType.GO_HOME), 0L, -1)))
    }

    @Test fun rejectsDuplicateOrInvalidId() {
        val first = added(RecordingActionRules.tryAdd(emptyList(), nav("d1", 0, MacroActionType.GO_HOME), 0L, 0))
        assertTrue(rejected(RecordingActionRules.tryAdd(first, nav("d1", 0, MacroActionType.GO_BACK), 0L, 0)))
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), nav("bad id", 0, MacroActionType.GO_HOME), 0L, 0)))
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), nav("", 0, MacroActionType.GO_HOME), 0L, 0)))
    }

    @Test fun launchAppNeedsValidPackageAndLabel() {
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), app("l1", 0, pkg = ""), 0L, 0)))
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), app("l2", 0, pkg = "nodots"), 0L, 0)))
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), app("l3", 0, label = "  "), 0L, 0)))
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), app("l4", 0, label = "x".repeat(101)), 0L, 0)))
    }

    @Test fun navigationActionsMustNotCarryAppInfo() {
        val withPkg = nav("n1", 0, MacroActionType.GO_HOME).copy(packageName = "com.android.chrome")
        val withLabel = nav("n2", 0, MacroActionType.GO_BACK).copy(appLabel = "Chrome")
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), withPkg, 0L, 0)))
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), withLabel, 0L, 0)))
    }

    @Test fun waitMustBeInRange() {
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), nav("w1", 0, MacroActionType.GO_HOME, -1L), 0L, 0)))
        assertTrue(rejected(RecordingActionRules.tryAdd(emptyList(), nav("w2", 0, MacroActionType.GO_HOME, 60_001L), 0L, 0)))
        assertTrue(!rejected(RecordingActionRules.tryAdd(emptyList(), nav("w3", 0, MacroActionType.GO_HOME, 0L), 0L, 0)))
        assertTrue(!rejected(RecordingActionRules.tryAdd(emptyList(), nav("w4", 0, MacroActionType.GO_HOME, 60_000L), 0L, 0)))
    }

    @Test fun rejectsBeyondMaxActions() {
        val full = (1..MacroStore.MAX_ACTIONS).map { nav("m$it", 0, MacroActionType.GO_BACK, 0L) }
        assertTrue(rejected(RecordingActionRules.tryAdd(full, nav("extra", 0, MacroActionType.GO_BACK, 0L), 0L, 0)))
        val almost = full.dropLast(1)
        assertEquals(MacroStore.MAX_ACTIONS, added(RecordingActionRules.tryAdd(almost, nav("extra", 0, MacroActionType.GO_BACK, 0L), 0L, 0)).size)
    }

    @Test fun enforcesTenMinuteBudgetIncludingActionWaits() {
        val limit = MacroStore.MAX_MACRO_DURATION_MS
        val existing = listOf(nav("t1", 0, MacroActionType.GO_HOME, 10_000L))
        // exactly at the limit is accepted
        val exact = nav("t2", 0, MacroActionType.GO_BACK, 5_000L)
        assertTrue(!rejected(RecordingActionRules.tryAdd(existing, exact, limit - 15_000L, 0)))
        // one millisecond over is rejected
        assertTrue(rejected(RecordingActionRules.tryAdd(existing, exact, limit - 14_999L, 0)))
    }

    @Test fun defaultWaitsMatchManagerDefaults() {
        assertEquals(2_500L, RecordingActionRules.defaultWaitMs(MacroActionType.LAUNCH_APP))
        assertEquals(1_200L, RecordingActionRules.defaultWaitMs(MacroActionType.GO_HOME))
        assertEquals(700L, RecordingActionRules.defaultWaitMs(MacroActionType.GO_BACK))
        assertEquals(1_000L, RecordingActionRules.defaultWaitMs(MacroActionType.GO_RECENTS))
        assertEquals(8_000L, RecordingActionRules.defaultWaitMs(MacroActionType.OPEN_INTERNET_PANEL))
    }

    @Test fun labelsAreDistinct() {
        val labels = listOf(
            app("z1", 0), nav("z2", 0, MacroActionType.GO_HOME), nav("z3", 0, MacroActionType.GO_BACK),
            nav("z4", 0, MacroActionType.GO_RECENTS), nav("z5", 0, MacroActionType.OPEN_INTERNET_PANEL)
        ).map { RecordingActionRules.label(it) }
        assertEquals(5, labels.toSet().size)
        assertTrue(labels[0].contains("Chrome"))
    }
}
