package com.grandmaconnect

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Coordinates are normalized to the full physical display (0.0..1.0). */
data class NormalizedPoint(val x: Float, val y: Float)
data class MacroStroke(val startOffsetMs: Long, val durationMs: Long, val points: List<NormalizedPoint>)
data class MacroGestureGroup(val startOffsetMs: Long, val strokes: List<MacroStroke>)
data class TouchMacro(
    val id: String,
    val name: String,
    val createdAt: Long,
    val recordedScreenWidth: Int,
    val recordedScreenHeight: Int,
    val totalDurationMs: Long,
    val groups: List<MacroGestureGroup>
)

object MacroStore {
    private const val SCHEMA_VERSION = 1
    private const val MAX_GROUPS = 200
    private const val MAX_STROKES_PER_GROUP = 10
    private const val MAX_POINTS_PER_STROKE = 1500
    private const val MAX_TOTAL_POINTS = 12000
    const val MAX_MACRO_DURATION_MS = 45_000L

    private fun folder(context: Context): File = File(context.filesDir, "macros").apply { mkdirs() }

    fun save(context: Context, macro: TouchMacro) {
        validate(macro)
        require(macro.name.trim().isNotEmpty()) { "نام ماکرو خالی است." }
        val target = File(folder(context), "${macro.id}.json")
        val temp = File(folder(context), "${macro.id}.json.tmp")
        temp.writeText(toJson(macro).toString(), Charsets.UTF_8)
        if (target.exists() && !target.delete()) throw IllegalStateException("فایل قبلی حذف نشد.")
        if (!temp.renameTo(target)) {
            temp.copyTo(target, overwrite = true)
            temp.delete()
        }
    }

    fun loadAll(context: Context): List<TouchMacro> {
        val dir = folder(context)
        return dir.listFiles { file -> file.isFile && file.extension == "json" }
            ?.mapNotNull { file ->
                try {
                    fromJson(JSONObject(file.readText(Charsets.UTF_8))).also(::validate)
                } catch (_: Exception) {
                    null
                }
            }
            ?.sortedByDescending { it.createdAt }
            ?: emptyList()
    }

    fun delete(context: Context, id: String): Boolean {
        if (!id.matches(Regex("[A-Za-z0-9_-]{1,80}"))) return false
        val file = File(folder(context), "$id.json")
        return !file.exists() || file.delete()
    }

    fun validate(macro: TouchMacro) {
        require(macro.id.matches(Regex("[A-Za-z0-9_-]{1,80}"))) { "شناسه ماکرو نامعتبر است." }
        require(macro.name.length in 1..40) { "نام ماکرو باید بین ۱ تا ۴۰ نویسه باشد." }
        require(macro.recordedScreenWidth in 200..10000 && macro.recordedScreenHeight in 200..20000) {
            "اندازه صفحه ضبط‌شده نامعتبر است."
        }
        require(macro.groups.isNotEmpty() && macro.groups.size <= MAX_GROUPS) { "تعداد حرکت‌ها خارج از محدوده مجاز است." }
        require(macro.totalDurationMs in 1..MAX_MACRO_DURATION_MS) { "مدت ماکرو باید حداکثر ۴۵ ثانیه باشد." }
        var points = 0
        var previousStart = -1L
        for (group in macro.groups) {
            require(group.startOffsetMs in 0 until macro.totalDurationMs) { "زمان شروع یک حرکت نامعتبر است." }
            require(group.startOffsetMs >= previousStart) { "ترتیب حرکت‌ها نامعتبر است." }
            previousStart = group.startOffsetMs
            require(group.strokes.isNotEmpty() && group.strokes.size <= MAX_STROKES_PER_GROUP) {
                "تعداد انگشتان/حرکت هم‌زمان خارج از محدوده است."
            }
            for (stroke in group.strokes) {
                require(stroke.startOffsetMs in 0..MAX_MACRO_DURATION_MS) { "زمان شروع لمس نامعتبر است." }
                require(stroke.durationMs in 1..MACRO_MAX_STROKE_MS) { "مدت یک لمس نامعتبر است." }
                require(stroke.startOffsetMs + stroke.durationMs <= 8_000L) { "زمان یک گروه لمس بیش از حد مجاز است." }
                require(group.startOffsetMs + stroke.startOffsetMs + stroke.durationMs <= macro.totalDurationMs + 50L) {
                    "زمان حرکت خارج از محدوده طول ماکرو است."
                }
                require(stroke.points.isNotEmpty() && stroke.points.size <= MAX_POINTS_PER_STROKE) {
                    "تعداد نقاط یک حرکت خارج از محدوده است."
                }
                points += stroke.points.size
                require(points <= MAX_TOTAL_POINTS) { "تعداد کل نقاط بیش از حد مجاز است." }
                stroke.points.forEach { point ->
                    require(point.x.isFinite() && point.y.isFinite() && point.x in 0f..1f && point.y in 0f..1f) {
                        "مختصات لمس نامعتبر است."
                    }
                }
            }
        }
    }

    private const val MACRO_MAX_STROKE_MS = 8_000L

    private fun toJson(macro: TouchMacro): JSONObject {
        val groupsJson = JSONArray()
        macro.groups.forEach { group ->
            val strokesJson = JSONArray()
            group.strokes.forEach { stroke ->
                val pointsJson = JSONArray()
                stroke.points.forEach { point ->
                    pointsJson.put(JSONObject().put("x", point.x.toDouble()).put("y", point.y.toDouble()))
                }
                strokesJson.put(JSONObject().put("startOffsetMs", stroke.startOffsetMs).put("durationMs", stroke.durationMs).put("points", pointsJson))
            }
            groupsJson.put(JSONObject().put("startOffsetMs", group.startOffsetMs).put("strokes", strokesJson))
        }
        return JSONObject()
            .put("schemaVersion", SCHEMA_VERSION)
            .put("id", macro.id)
            .put("name", macro.name)
            .put("createdAt", macro.createdAt)
            .put("recordedScreenWidth", macro.recordedScreenWidth)
            .put("recordedScreenHeight", macro.recordedScreenHeight)
            .put("totalDurationMs", macro.totalDurationMs)
            .put("groups", groupsJson)
    }

    private fun fromJson(json: JSONObject): TouchMacro {
        require(json.optInt("schemaVersion", -1) == SCHEMA_VERSION) { "نسخه فایل ماکرو پشتیبانی نمی‌شود." }
        val groupsArray = json.getJSONArray("groups")
        val groups = ArrayList<MacroGestureGroup>(groupsArray.length())
        for (i in 0 until groupsArray.length()) {
            val groupJson = groupsArray.getJSONObject(i)
            val strokeArray = groupJson.getJSONArray("strokes")
            val strokes = ArrayList<MacroStroke>(strokeArray.length())
            for (j in 0 until strokeArray.length()) {
                val strokeJson = strokeArray.getJSONObject(j)
                val pointArray = strokeJson.getJSONArray("points")
                val pointList = ArrayList<NormalizedPoint>(pointArray.length())
                for (k in 0 until pointArray.length()) {
                    val point = pointArray.getJSONObject(k)
                    pointList += NormalizedPoint(point.getDouble("x").toFloat(), point.getDouble("y").toFloat())
                }
                strokes += MacroStroke(strokeJson.getLong("startOffsetMs"), strokeJson.getLong("durationMs"), pointList)
            }
            groups += MacroGestureGroup(groupJson.getLong("startOffsetMs"), strokes)
        }
        return TouchMacro(
            id = json.getString("id"),
            name = json.getString("name"),
            createdAt = json.getLong("createdAt"),
            recordedScreenWidth = json.getInt("recordedScreenWidth"),
            recordedScreenHeight = json.getInt("recordedScreenHeight"),
            totalDurationMs = json.getLong("totalDurationMs"),
            groups = groups
        )
    }

    fun newId(): String = UUID.randomUUID().toString().replace("-", "")
}
