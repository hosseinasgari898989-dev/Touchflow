package com.grandmaconnect

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.max

class TouchCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private data class ActiveStroke(
        val pointerId: Int,
        val startedAt: Long,
        val points: MutableList<NormalizedPoint> = mutableListOf(),
        var lastX: Float = 0f,
        var lastY: Float = 0f,
        var lastAt: Long = 0L
    )

    private val completedGroups = mutableListOf<MacroGestureGroup>()
    private val activeStrokes = linkedMapOf<Int, ActiveStroke>()
    private var currentGroupStrokes = mutableListOf<MacroStroke>()
    private var currentGroupStart = 0L
    private var recordingStart = 0L
    private var screenWidth = 0
    private var screenHeight = 0
    private var recording = false
    private val limitRunnable = Runnable {
        if (recording) {
            stopRecording()
            onLimitReached?.invoke()
        }
    }

    var onLimitReached: (() -> Unit)? = null

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(232, 237, 244)
        strokeWidth = dp(1f)
    }
    private val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(45, 105, 180)
        style = Paint.Style.STROKE
        strokeWidth = dp(5f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(45, 105, 180) }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(130, 140, 155)
        textSize = dp(16f)
        textAlign = Paint.Align.CENTER
    }

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        contentDescription = "سطح ضبط حرکت انگشت"
    }

    fun startRecording() {
        completedGroups.clear()
        activeStrokes.clear()
        currentGroupStrokes.clear()
        // Capture the physical display size at the start, before any gesture is received.
        currentScreenSize()
        recordingStart = SystemClock.elapsedRealtime()
        recording = true
        removeCallbacks(limitRunnable)
        postDelayed(limitRunnable, MacroStore.MAX_MACRO_DURATION_MS)
        invalidate()
    }

    fun stopRecording(): List<MacroGestureGroup> {
        if (recording) {
            val now = SystemClock.elapsedRealtime()
            val location = IntArray(2)
            getLocationOnScreen(location)
            activeStrokes.values.toList().forEach { stroke -> finishStroke(stroke, now, location) }
            activeStrokes.clear()
            finishGroup()
            recording = false
            removeCallbacks(limitRunnable)
        }
        invalidate()
        return completedGroups.toList()
    }

    fun isRecording(): Boolean = recording
    fun elapsedMs(): Long = if (recording) (SystemClock.elapsedRealtime() - recordingStart).coerceAtMost(MacroStore.MAX_MACRO_DURATION_MS) else 0L

    fun currentScreenSize(): Pair<Int, Int> {
        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        screenWidth = max(1, metrics.widthPixels)
        screenHeight = max(1, metrics.heightPixels)
        return screenWidth to screenHeight
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
        val step = dp(32f)
        var x = 0f
        while (x <= width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += step
        }
        var y = 0f
        while (y <= height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += step
        }

        val allStrokes = completedGroups.flatMap { it.strokes }
        allStrokes.forEach { drawStroke(canvas, it.points) }
        activeStrokes.values.forEach { stroke -> drawNormalizedPath(canvas, stroke.points) }
        currentGroupStrokes.forEach { drawStroke(canvas, it.points) }

        if (completedGroups.isEmpty() && activeStrokes.isEmpty() && currentGroupStrokes.isEmpty()) {
            canvas.drawText("حرکت انگشت را داخل این کادر انجام بده", width / 2f, height / 2f, hintPaint)
            canvas.drawText("ضبط فقط در همین کادر انجام می‌شود", width / 2f, height / 2f + dp(28f), hintPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!recording) return true
        if (elapsedMs() >= MacroStore.MAX_MACRO_DURATION_MS) {
            stopRecording()
            onLimitReached?.invoke()
            return true
        }
        val location = IntArray(2)
        getLocationOnScreen(location)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                currentGroupStrokes = mutableListOf()
                currentGroupStart = SystemClock.elapsedRealtime() - recordingStart
                addPointer(event, event.actionIndex, location)
                invalidate()
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                addPointer(event, event.actionIndex, location)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) addPoint(event, i, location)
                invalidate()
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val pointerId = event.getPointerId(event.actionIndex)
                addPoint(event, event.actionIndex, location, force = true)
                activeStrokes.remove(pointerId)?.let { finishStroke(it, SystemClock.elapsedRealtime(), location) }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                val pointerId = event.getPointerId(event.actionIndex)
                addPoint(event, event.actionIndex, location, force = true)
                activeStrokes.remove(pointerId)?.let { finishStroke(it, SystemClock.elapsedRealtime(), location) }
                activeStrokes.values.toList().forEach { finishStroke(it, SystemClock.elapsedRealtime(), location) }
                activeStrokes.clear()
                finishGroup()
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                val now = SystemClock.elapsedRealtime()
                activeStrokes.values.toList().forEach { finishStroke(it, now, location) }
                activeStrokes.clear()
                finishGroup()
                invalidate()
                return true
            }
        }
        return true
    }

    private fun addPointer(event: MotionEvent, index: Int, location: IntArray) {
        val id = event.getPointerId(index)
        val now = SystemClock.elapsedRealtime()
        val x = event.getX(index) + location[0]
        val y = event.getY(index) + location[1]
        val point = normalize(x, y)
        val stroke = ActiveStroke(id, now, mutableListOf(point), x, y, now)
        activeStrokes[id] = stroke
    }

    private fun addPoint(event: MotionEvent, index: Int, location: IntArray, force: Boolean = false) {
        val id = event.getPointerId(index)
        val stroke = activeStrokes[id] ?: return
        val x = event.getX(index) + location[0]
        val y = event.getY(index) + location[1]
        val now = SystemClock.elapsedRealtime()
        if (force || abs(x - stroke.lastX) > dp(2f) || abs(y - stroke.lastY) > dp(2f) || now - stroke.lastAt >= 45L) {
            if (stroke.points.size < 1500) stroke.points += normalize(x, y)
            stroke.lastX = x
            stroke.lastY = y
            stroke.lastAt = now
        }
    }

    private fun normalize(x: Float, y: Float): NormalizedPoint {
        if (screenWidth <= 0 || screenHeight <= 0) currentScreenSize()
        return NormalizedPoint(
            (x / screenWidth.toFloat()).coerceIn(0f, 1f),
            (y / screenHeight.toFloat()).coerceIn(0f, 1f)
        )
    }

    private fun finishStroke(active: ActiveStroke, now: Long, location: IntArray) {
        val rawStartOffset = (active.startedAt - (recordingStart + currentGroupStart)).coerceAtLeast(0L)
        val startOffset = rawStartOffset.coerceAtMost(7_999L)
        val remainingGroupTime = (8_000L - startOffset).coerceAtLeast(1L)
        val remainingMacroTime = (MacroStore.MAX_MACRO_DURATION_MS - currentGroupStart - startOffset).coerceAtLeast(1L)
        val duration = (now - active.startedAt).coerceAtLeast(1L)
            .coerceAtMost(remainingGroupTime)
            .coerceAtMost(remainingMacroTime)
        val points = active.points.toList().ifEmpty { listOf(normalize(active.lastX, active.lastY)) }
        if (currentGroupStrokes.size < 10) currentGroupStrokes += MacroStroke(startOffset, duration, points)
    }

    private fun finishGroup() {
        if (currentGroupStrokes.isNotEmpty() && completedGroups.size < 200) {
            completedGroups += MacroGestureGroup(currentGroupStart.coerceAtLeast(0L), currentGroupStrokes.toList())
        }
        currentGroupStrokes.clear()
    }

    private fun drawStroke(canvas: Canvas, points: List<NormalizedPoint>) = drawNormalizedPath(canvas, points)

    private fun drawNormalizedPath(canvas: Canvas, points: List<NormalizedPoint>) {
        if (points.isEmpty()) return
        val location = IntArray(2)
        getLocationOnScreen(location)
        if (screenWidth <= 0 || screenHeight <= 0) currentScreenSize()
        val path = Path()
        val first = points.first()
        val firstX = first.x * screenWidth - location[0]
        val firstY = first.y * screenHeight - location[1]
        path.moveTo(firstX, firstY)
        points.drop(1).forEach { point ->
            path.lineTo(point.x * screenWidth - location[0], point.y * screenHeight - location[1])
        }
        canvas.drawPath(path, pathPaint)
        canvas.drawCircle(firstX, firstY, dp(5f), dotPaint)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
