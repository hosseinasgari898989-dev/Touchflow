package com.grandmaconnect

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.util.DisplayMetrics
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Date
import java.text.DateFormat

class MainActivity : Activity() {
    private var homeStatus: TextView? = null
    private var currentPage = "home"
    private var orientationBeforeRecording: Int? = null

    override fun onResume() {
        super.onResume()
        if (currentPage == "home") refreshHomeStatus()
    }

    override fun onDestroy() {
        restoreRecordingOrientation()
        super.onDestroy()
    }

    private fun lockOrientationForRecording() {
        if (orientationBeforeRecording == null) {
            orientationBeforeRecording = requestedOrientation
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LOCKED
        }
    }

    private fun restoreRecordingOrientation() {
        val previous = orientationBeforeRecording ?: return
        orientationBeforeRecording = null
        requestedOrientation = previous
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(245, 247, 250)
        window.navigationBarColor = Color.rgb(245, 247, 250)
        if (Build.VERSION.SDK_INT >= 23) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        showHome()
    }


    private fun showHome() {
        currentPage = "home"
        val root = pageContainer()
        root.addView(title("Grandma Connect", 30f))
        root.addView(body("ضبط حرکت، ذخیره ماکرو و اجرای لمس واقعی با اجازه خودت."))

        val status = TextView(this).apply {
            textSize = 17f
            setTextColor(Color.rgb(45, 55, 70))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(235, 241, 249))
        }
        homeStatus = status
        root.addView(status, matchWrap())
        refreshHomeStatus()

        root.addView(actionButton("۱. فعال‌سازی مجوز اجرای لمس") {
            AlertDialog.Builder(this)
                .setTitle("مجوز دسترسی اندروید")
                .setMessage("برای اجرای لمس در برنامه‌های دیگر، اندروید باید سرویس دسترس‌پذیری Grandma Connect را فعال کند. این انتخاب فقط در تنظیمات خود گوشی انجام می‌شود. برنامه محتوای صفحه را نمی‌خواند.")
                .setNegativeButton("بعداً", null)
                .setPositiveButton("رفتن به تنظیمات") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    } catch (_: Exception) {
                        toast("تنظیمات دسترس‌پذیری در این گوشی باز نشد.")
                    }
                }.show()
        })
        root.addView(actionButton("۲. ضبط حرکت جدید") { showRecorder() })
        root.addView(actionButton("۳. ماکروهای ذخیره‌شده") { showSavedMacros() })
        root.addView(actionButton("راهنما و محدودیت‌ها") { showGuide() })

        root.addView(body("حریم خصوصی: اطلاعات ماکرو فقط داخل حافظه همین گوشی ذخیره می‌شود. هیچ حساب، سرور یا اتصال اینترنتی لازم نیست."))
        root.addView(body("توجه: ماکروها مختص مختصات صفحه‌اند. قبل از اجرا، برنامه مقصد و نتیجه لمس‌ها را بررسی کن."))
        setContentView(root)
    }

    private fun refreshHomeStatus() {
        val enabled = MacroAccessibilityService.isEnabledInSettings(this)
        val serviceReady = MacroAccessibilityService.instance != null
        homeStatus?.text = when {
            enabled && serviceReady -> "وضعیت مجوز: فعال و آماده اجرای لمس"
            enabled -> "وضعیت مجوز: در تنظیمات روشن است؛ اتصال سرویس هنوز آماده نشده. یک‌بار برنامه را باز کن."
            else -> "وضعیت مجوز: هنوز فعال نشده. برای اجرای واقعی لمس، دکمه فعال‌سازی را بزن. ضبط و ذخیره بدون این مجوز کار می‌کند."
        }
    }

    private fun showRecorder() {
        currentPage = "record"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(245, 247, 250))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(title("ضبط ماکرو", 26f))
        root.addView(body("حرکت انگشت را داخل کادر انجام بده. برای پایان، دکمه بیرون کادر را بزن. لمس‌ها فقط در همین کادر ضبط می‌شوند."))

        val nameInput = EditText(this).apply {
            hint = "نام ماکرو (مثلاً بازکردن صفحه اصلی)"
            setText("ماکرو جدید")
            textSize = 17f
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(nameInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(8) })

        val status = body("آماده ضبط. ابتدا دکمه شروع را بزن.")
        root.addView(status)

        val canvas = TouchCanvasView(this)
        root.addView(canvas, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val start = actionButton("شروع ضبط") { }
        val stop = actionButton("پایان ضبط") { }.apply { isEnabled = false }
        val save = actionButton("ذخیره ماکرو") { }.apply { isEnabled = false }

        start.setOnClickListener {
            lockOrientationForRecording()
            canvas.startRecording()
            status.text = "در حال ضبط… فقط داخل کادر لمس کن. جهت صفحه تا پایان ضبط ثابت می‌ماند؛ حداکثر زمان ۴۵ ثانیه است."
            start.isEnabled = false
            stop.isEnabled = true
            save.isEnabled = false
        }
        stop.setOnClickListener {
            val elapsed = canvas.elapsedMs().coerceAtLeast(1L)
            val groups = canvas.stopRecording()
            val total = groups.maxOfOrNull { group -> group.startOffsetMs + (group.strokes.maxOfOrNull { it.startOffsetMs + it.durationMs } ?: 0L) }
                ?.coerceAtLeast(elapsed) ?: elapsed
            capturedGroups = groups
            capturedDuration = total.coerceAtMost(MacroStore.MAX_MACRO_DURATION_MS)
            capturedScreen = canvas.currentScreenSize()
            restoreRecordingOrientation()
            start.isEnabled = true
            stop.isEnabled = false
            save.isEnabled = groups.isNotEmpty()
            status.text = if (groups.isEmpty()) "هیچ حرکتی ضبط نشد. دوباره شروع کن." else "${groups.size} بخش حرکت ضبط شد. حالا ذخیره را بزن."
        }
        save.setOnClickListener {
            val name = nameInput.text?.toString()?.trim().orEmpty()
            if (name.isBlank() || name.length > 40) {
                toast("نام ماکرو باید بین ۱ تا ۴۰ نویسه باشد.")
                return@setOnClickListener
            }
            try {
                val (screenW, screenH) = capturedScreen
                val macro = TouchMacro(
                    id = MacroStore.newId(),
                    name = name,
                    createdAt = System.currentTimeMillis(),
                    recordedScreenWidth = screenW,
                    recordedScreenHeight = screenH,
                    totalDurationMs = capturedDuration.coerceIn(1L, MacroStore.MAX_MACRO_DURATION_MS),
                    groups = capturedGroups
                )
                MacroStore.save(this, macro)
                toast("ماکرو با موفقیت ذخیره شد.")
                showSavedMacros()
            } catch (error: Exception) {
                toast("ذخیره انجام نشد: ${error.message ?: "خطای نامشخص"}")
            }
        }

        val cancel = actionButton("بازگشت") {
            if (canvas.isRecording()) {
                AlertDialog.Builder(this)
                    .setMessage("ضبط در حال انجام است. حرکت‌های ضبط‌شده کنار گذاشته شوند؟")
                    .setNegativeButton("ادامه ضبط", null)
                    .setPositiveButton("لغو ضبط") { _, _ -> canvas.stopRecording(); restoreRecordingOrientation(); showHome() }
                    .show()
            } else showHome()
        }

        canvas.onLimitReached = {
            val elapsed = MacroStore.MAX_MACRO_DURATION_MS
            capturedGroups = canvas.stopRecording()
            capturedDuration = elapsed
            capturedScreen = canvas.currentScreenSize()
            restoreRecordingOrientation()
            start.isEnabled = true
            stop.isEnabled = false
            save.isEnabled = capturedGroups.isNotEmpty()
            status.text = "حداکثر ۴۵ ثانیه تمام شد. حرکت‌ها را ذخیره کن یا دوباره ضبط کن."
        }

        controls.addView(start, weightedButton())
        controls.addView(stop, weightedButton())
        root.addView(controls)
        root.addView(save)
        root.addView(cancel)
        setContentView(root)

    }

    private var capturedGroups: List<MacroGestureGroup> = emptyList()
    private var capturedDuration: Long = 1L
    private var capturedScreen: Pair<Int, Int> = 1080 to 2400

    private fun showSavedMacros() {
        currentPage = "saved"
        val root = pageContainer()
        root.addView(title("ماکروهای ذخیره‌شده", 26f))
        root.addView(body("برای اجرای لمس واقعی، اول برنامه مقصد را مشخص کن. پس از تأیید، ۴ ثانیه فرصت داری از Grandma Connect خارج شوی."))
        val macros = MacroStore.loadAll(this)
        if (macros.isEmpty()) {
            root.addView(body("هنوز ماکرویی ذخیره نشده است."))
        } else {
            macros.forEach { macro ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    setBackgroundColor(Color.WHITE)
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                }
                val name = TextView(this).apply {
                    text = macro.name
                    textSize = 20f
                    setTypeface(typeface, Typeface.BOLD)
                    setTextColor(Color.rgb(35, 45, 60))
                }
                card.addView(name)
                card.addView(body("${macro.groups.size} بخش حرکت · ${(macro.totalDurationMs / 1000f).let { String.format("%.1f", it) }} ثانیه"))
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                actions.addView(actionButton("اجرای واقعی") { confirmAndPlay(macro) }, weightedButton())
                actions.addView(actionButton("حذف") {
                    AlertDialog.Builder(this)
                        .setMessage("ماکرو «${macro.name}» حذف شود؟")
                        .setNegativeButton("لغو", null)
                        .setPositiveButton("حذف") { _, _ ->
                            MacroStore.delete(this, macro.id)
                            showSavedMacros()
                        }.show()
                }, weightedButton())
                card.addView(actions)
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(10)
                root.addView(card, lp)
            }
        }
        root.addView(actionButton("ضبط ماکرو جدید") { showRecorder() })
        root.addView(actionButton("بازگشت") { showHome() })
        setContentView(root)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != 41) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            toast("اجازه اعلان فعال شد. حالا می‌توانی اجرای آزمایشی را شروع کنی.")
        } else {
            AlertDialog.Builder(this)
                .setTitle("اجازه اعلان داده نشد")
                .setMessage("برای اجرای ماکرو در برنامه‌های دیگر، اعلان توقف لازم است. از تنظیمات اعلان برنامه اجازه را فعال کن.")
                .setNegativeButton("بعداً", null)
                .setPositiveButton("تنظیمات اعلان") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
                    } catch (_: Exception) {
                        toast("تنظیمات اعلان باز نشد؛ از تنظیمات گوشی وارد برنامه‌ها و سپس اعلان‌های Grandma Connect شو.")
                    }
                }
                .show()
        }
    }

    private fun confirmAndPlay(macro: TouchMacro) {
        val currentMetrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(currentMetrics)
        val recordedPortrait = macro.recordedScreenHeight >= macro.recordedScreenWidth
        val currentPortrait = currentMetrics.heightPixels >= currentMetrics.widthPixels
        if (recordedPortrait != currentPortrait) {
            AlertDialog.Builder(this)
                .setTitle("جهت صفحه متفاوت است")
                .setMessage("این ماکرو در جهت دیگری ضبط شده است. برای جلوگیری از لمس اشتباه، صفحه گوشی را به همان جهت زمان ضبط برگردان و دوباره امتحان کن.")
                .setPositiveButton("متوجه شدم", null)
                .show()
            return
        }
        if (!MacroAccessibilityService.isEnabledInSettings(this)) {
            AlertDialog.Builder(this)
                .setTitle("مجوز لازم است")
                .setMessage("ابتدا سرویس Grandma Connect را در تنظیمات دسترس‌پذیری فعال کن. بدون این اجازه لمس واقعی اجرا نمی‌شود.")
                .setNegativeButton("لغو", null)
                .setPositiveButton("رفتن به تنظیمات") { _, _ -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                .show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this)
                .setTitle("اعلان توقف لازم است")
                .setMessage("برای اینکه دکمه توقف هنگام اجرای ماکرو در دسترس باشد، ابتدا اجازه اعلان را فعال کن.")
                .setNegativeButton("لغو", null)
                .setPositiveButton("درخواست اجازه") { _, _ -> requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41) }
                .show()
            return
        }
        val service = MacroAccessibilityService.instance
        if (service == null) {
            toast("سرویس هنوز متصل نشده. یک‌بار به صفحه اصلی برگرد و دوباره امتحان کن.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("تأیید اجرای لمس واقعی")
            .setMessage("ماکرو «${macro.name}» در برنامه‌ای که باز است اجرا می‌شود. پس از شروع، ۴ ثانیه برای رفتن به برنامه مقصد فرصت داری. ممکن است لمس‌ها پیام ارسال کنند یا چیزی را تغییر دهند؛ فقط در صفحه‌ای اجرا کن که خودت بررسی کرده‌ای. اعلان توقف را روشن نگه دار.")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("تأیید و شروع") { _, _ ->
                try {
                    service.playMacro(macro)
                    toast("شروع شد؛ حالا سریع برنامه مقصد را باز کن.")
                } catch (error: Exception) {
                    toast("شروع نشد: ${error.message ?: "خطای نامشخص"}")
                }
            }.show()
    }

    private fun showGuide() {
        currentPage = "guide"
        val root = pageContainer()
        root.addView(title("راهنما و محدودیت‌ها", 26f))
        root.addView(body("۱) مجوز اجرای لمس از تنظیمات دسترس‌پذیری اندروید فعال می‌شود؛ برنامه نمی‌تواند آن را بدون تأیید تو روشن کند."))
        root.addView(body("۲) ضبط فقط وقتی انجام می‌شود که انگشت را داخل کادر Grandma Connect حرکت بدهی. این نسخه لمس‌های سایر برنامه‌ها را مخفیانه ضبط نمی‌کند."))
        root.addView(body("۳) هنگام پخش، مختصات ثبت‌شده روی صفحه فعلی گوشی اجرا می‌شوند. اگر صفحه مقصد تغییر کرده باشد یا چیدمان برنامه فرق کند، ممکن است لمس به جای اشتباه بخورد."))
        root.addView(body("۴) هنگام ضبط، جهت صفحه قفل می‌شود تا مختصات به‌هم نریزد. حداکثر طول هر ماکرو ۴۵ ثانیه و طول هر حرکت پیوسته ۸ ثانیه است. تا ۱۰ انگشت هم‌زمان در هر گروه پشتیبانی می‌شود."))
        root.addView(body("۵) اعلان توقف برای جلوگیری از ادامه گروه‌های بعدی در نظر گرفته شده؛ لمس فعلی ممکن است تا پایان همان حرکت ادامه یابد."))
        root.addView(body("۶) دیتای موبایل، VPN، رمزها، تماس‌ها، پیام‌ها، خریدها و محتوای صفحه به‌صورت خودکار مدیریت یا خوانده نمی‌شوند."))
        root.addView(actionButton("بازگشت") { showHome() })
        setContentView(root)
    }

    private fun pageContainer(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(14))
        setBackgroundColor(Color.rgb(245, 247, 250))
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        isFocusableInTouchMode = true
    }

    private fun title(text: String, size: Float): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.rgb(30, 45, 65))
        gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun body(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTextColor(Color.rgb(70, 80, 95))
        gravity = Gravity.RIGHT
        setPadding(0, dp(6), 0, dp(8))
        setLineSpacing(dp(3).toFloat(), 1.0f)
    }

    private fun actionButton(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 17f
        isAllCaps = false
        minHeight = dp(54)
        setPadding(dp(10), dp(8), dp(10), dp(8))
        setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun weightedButton() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(4); marginStart = dp(4) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
