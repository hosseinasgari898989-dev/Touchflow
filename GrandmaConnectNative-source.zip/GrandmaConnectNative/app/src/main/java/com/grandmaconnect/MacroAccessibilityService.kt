package com.grandmaconnect

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class MacroAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: MacroAccessibilityService? = null
            private set

        fun isEnabledInSettings(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val component = ComponentName(context, MacroAccessibilityService::class.java).flattenToString()
            return enabled.split(':').any { it.equals(component, ignoreCase = true) }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var stopRequested = false
    @Volatile private var playing = false
    private var currentMacroName = ""
    private var currentNotificationId = 701
    private val channelId = "grandma_macro_playback"

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        createNotificationChannel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally does not read or store screen content.
    }

    override fun onInterrupt() {
        stopPlayback()
    }

    override fun onDestroy() {
        // Prevent delayed groups from firing after Android disconnects the service.
        handler.removeCallbacksAndMessages(null)
        if (playing) {
            playing = false
            stopRequested = true
            cancelNotification()
        }
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun playMacro(macro: TouchMacro) {
        if (playing) throw IllegalStateException("یک ماکرو در حال اجراست.")
        MacroStore.validate(macro)
        playing = true
        stopRequested = false
        currentMacroName = macro.name
        showNotification("۴ ثانیه فرصت داری برنامه مقصد را باز کنی")
        handler.postDelayed({ playGroup(macro, 0) }, 4_000L)
    }

    fun stopPlayback() {
        if (!playing) return
        stopRequested = true
        updateNotification("توقف درخواست شد؛ حرکت جاری ممکن است کامل شود")
    }

    private fun playGroup(macro: TouchMacro, index: Int) {
        if (stopRequested) {
            playing = false
            updateNotification("بازپخش متوقف شد")
            handler.postDelayed({ cancelNotification() }, 2500L)
            return
        }
        if (index >= macro.groups.size) {
            playing = false
            updateNotification("بازپخش تمام شد")
            handler.postDelayed({ cancelNotification() }, 3000L)
            return
        }

        val group = macro.groups[index]
        val gesture = try {
            buildGesture(group)
        } catch (error: Exception) {
            playing = false
            updateNotification("خطا در ساخت لمس: ${error.message ?: "نامشخص"}")
            handler.postDelayed({ cancelNotification() }, 5000L)
            return
        }

        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (stopRequested) {
                    playing = false
                    updateNotification("بازپخش متوقف شد")
                    handler.postDelayed({ cancelNotification() }, 2500L)
                    return
                }
                if (index + 1 >= macro.groups.size) {
                    playGroup(macro, index + 1)
                    return
                }
                val thisEnd = group.startOffsetMs + group.strokes.maxOfOrNull { it.startOffsetMs + it.durationMs }.orZero()
                val nextStart = macro.groups[index + 1].startOffsetMs
                val gap = (nextStart - thisEnd).coerceIn(0L, MacroStore.MAX_MACRO_DURATION_MS)
                handler.postDelayed({ playGroup(macro, index + 1) }, gap)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                playing = false
                updateNotification("اجرای لمس توسط اندروید لغو شد")
                handler.postDelayed({ cancelNotification() }, 4000L)
            }
        }, handler)

        if (!dispatched) {
            playing = false
            updateNotification("اندروید اجرای این لمس را نپذیرفت")
            handler.postDelayed({ cancelNotification() }, 4000L)
        }
    }

    private fun buildGesture(group: MacroGestureGroup): GestureDescription {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val builder = GestureDescription.Builder()
        group.strokes.forEach { stroke ->
            val first = stroke.points.first()
            val path = Path().apply {
                moveTo(first.x * metrics.widthPixels, first.y * metrics.heightPixels)
                stroke.points.drop(1).forEach { point ->
                    lineTo(point.x * metrics.widthPixels, point.y * metrics.heightPixels)
                }
                if (stroke.points.size == 1) lineTo(first.x * metrics.widthPixels, first.y * metrics.heightPixels)
            }
            builder.addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    stroke.startOffsetMs.coerceIn(0L, 45_000L),
                    stroke.durationMs.coerceIn(1L, 8_000L)
                )
            )
        }
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "وضعیت اجرای ماکرو", NotificationManager.IMPORTANCE_LOW)
            channel.description = "وضعیت و توقف بازپخش لمس‌ها"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showNotification(message: String) {
        val stopIntent = Intent(this, StopPlaybackReceiver::class.java).setAction("com.grandmaconnect.STOP_PLAYBACK")
        val stopPending = PendingIntent.getBroadcast(
            this,
            702,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Grandma Connect · $currentMacroName")
            .setContentText(message)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "توقف فوری", stopPending).build())
            .build()
        try {
            getSystemService(NotificationManager::class.java).notify(currentNotificationId, notification)
        } catch (_: SecurityException) {
            // Notification permission may be denied; playback remains bounded and user-started.
        }
    }

    private fun updateNotification(message: String) {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val notification = builder
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Grandma Connect · $currentMacroName")
            .setContentText(message)
            .setOngoing(false)
            .build()
        try {
            getSystemService(NotificationManager::class.java).notify(currentNotificationId, notification)
        } catch (_: SecurityException) {
        }
    }

    private fun cancelNotification() {
        getSystemService(NotificationManager::class.java).cancel(currentNotificationId)
    }

    private fun Long?.orZero(): Long = this ?: 0L
}

class StopPlaybackReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        MacroAccessibilityService.instance?.stopPlayback()
    }
}
