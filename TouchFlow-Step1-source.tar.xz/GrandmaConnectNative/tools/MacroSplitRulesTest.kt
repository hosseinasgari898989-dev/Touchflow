package com.grandmaconnect

private inline fun expectFailure(block: () -> Unit) {
    var failed = false
    try { block() } catch (_: IllegalArgumentException) { failed = true }
    check(failed) { "Expected validation failure" }
}

fun main() {
    check(MacroSplitRules.add(emptyList(), 4, 2) == listOf(2))
    check(MacroSplitRules.add(listOf(1, 3), 4, 2) == listOf(1, 2, 3))
    check(MacroSplitRules.remove(listOf(1, 2, 3), 4, 2) == listOf(1, 3))
    check(MacroSplitRules.isValid(listOf(1, 3), 4))
    check(!MacroSplitRules.isValid(listOf(0), 4))
    check(!MacroSplitRules.isValid(listOf(4), 4))
    check(!MacroSplitRules.isValid(listOf(2, 2), 4))
    check(!MacroSplitRules.isValid(listOf(3, 1), 4))
    expectFailure { MacroSplitRules.add(emptyList(), 4, 0) }
    expectFailure { MacroSplitRules.add(listOf(2), 4, 2) }
    println("MacroSplitRulesTest: 10 assertions passed")
}
