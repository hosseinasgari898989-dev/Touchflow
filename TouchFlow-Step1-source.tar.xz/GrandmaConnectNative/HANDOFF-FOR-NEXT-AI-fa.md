# تحویل کار به هوش مصنوعی/مهندس بعدی — TouchFlow (2026-11-20)

## مبنا
- سورس پایه: Artifact `touchflow-feature-pack-source` شمارهٔ 14575158079 (Run 44619393523)، tar.xz با SHA-256 `34d1369c69861e9d08a0b4c98c14cfa846dd0de202b87c608ba049a082df9151`. این سورس از قبل شامل اصلاح Crash شروع‌برنامه و اصلاح دکمهٔ ذخیره است.
- شاخهٔ GitHub: `feature/touchflow-feature-pack-bundle-fix-2026-11-19`. به `main` و APK/سورس baseline دست نزنید؛ بدون تأیید مالک PR/merge نکنید.
- دستگاه هدف: Samsung Galaxy A14 (SM-A145F/DS)، Android 13/API 33. package آزمایشی: `com.grandmaconnect.feature`.

## وضعیت: فقط در سورس نوشته شده؛ هیچ‌کدام Build یا روی دستگاه تست نشده
جزئیات: `FEATURE-PACK-2-NOTES-fa.md`. خلاصه: فونت Vazirmatn، AppPicker با جستجو، ویجت با انتخاب ماکرو در هر لمس (MacroPickerActivity)، جستجوی ماکرو، Pause/Resume پخش (schedule() در MacroAccessibilityService)، اقدام‌های Recents و پنل اینترنت، Pause/Resume ضبط و تأیید دور انداختن، تغییر نام/تکثیر/Export/Import/Backup.

## اولین کار: Build
1. Workflow شاخه (`.github/workflows/build-touchflow-feature-pack.yml`) هنوز مرحلهٔ «Apply minimal startup crash fix» را روی آرشیو اصلی اجرا می‌کند. این سورس از قبل اصلاح‌شده است؛ آن مرحله را بردارید (وگرنه شکست می‌خورد) و هش آرشیو را به هش آرشیو جدید تغییر دهید. بقیه (JUnit + assembleDebug، بررسی package/label/امضا) بماند.
2. هر خطای کامپایل را فقط از لاگ واقعی CI رفع کنید. کد بدون کامپایلر نوشته شده است.
3. نتیجه را در PROJECT_HANDOFF.md ثبت و دوباره از GitHub بخوانید.

## مانده (به ترتیب پیشنهادی)
1. ویرایشگر واقعی ماکرو: جابه‌جایی/تکثیر/حذف/ادغام گروه‌ها، تنظیم تأخیر، Undo/Redo (با مهاجرت Schema و تست).
2. تنظیمات پخش (سرعت، تکرار، تأخیر شروع)، صفحات راهنما/دسترس‌پذیری/حریم خصوصی.
3. تست‌های واحد زمان‌بند پخش و ضبط (منطق را به کلاس خالص جدا کنید).
4. طراحی Native از مرجع MagicPath (پروژه 474228529169580032؛ فقط مرجع بصری، React نیست).
5. ضبط سراسری: طرح در `docs/FULL-DISPLAY-POC-fa.md`. فقط پس از آزمایش واقعی روی A14؛ تا آن موقع «ضبط روی کل صفحه» ادعا نشود. onMotionEvent فقط API 34 است.
6. چک‌لیست دستگاه: `docs/DEVICE-ACCEPTANCE-CHECKLIST-fa.md` (هیچ موردی اجرا نشده).

## قواعد
- Build موفق ≠ تأیید روی گوشی. وضعیت‌ها: IMPLEMENTED / TESTED / VERIFIED ON DEVICE / NOT VERIFIED / BLOCKED BY ANDROID.
- Wi-Fi/دادهٔ همراه بی‌صدا قابل تغییر نیست (فقط پنل رسمی). «بستن اجباری برنامهٔ دیگر» وجود ندارد.
- مجوز اضافه نیفزایید؛ محتوای پنجرهٔ برنامه‌های دیگر خوانده نشود (`canRetrieveWindowContent=false`).
- APK قبلی با امضای متفاوت ممکن است روی نصب قبلی نصب نشود؛ فقط برنامهٔ Feature Preview را حذف کنید، نه baseline را.
- README-fa.md و TEST-CHECKLIST-fa.md قدیمی‌اند (Schema 2) و باید با Schema 3 و قابلیت‌های جدید هماهنگ شوند.
- سازگاری: ماکروهایی که Recents/پنل اینترنت دارند در نسخه‌های قدیمی برنامه خوانده نمی‌شوند.
