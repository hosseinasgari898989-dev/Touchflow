package com.grandmaconnect

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MacroNamingTest {
    @Test fun copyNameAddsSuffixAndStaysWithinLimit() {
        assertEquals("ماکرو (کپی)", MacroNaming.copyName("ماکرو"))
        val long = "a".repeat(40)
        val copy = MacroNaming.copyName(long)
        assertTrue(copy.length <= MacroNaming.MAX_NAME)
        assertTrue(copy.endsWith(" (کپی)"))
    }

    @Test fun fileNameIsSafeAndNeverEmpty() {
        assertEquals("my_macro.json", MacroNaming.fileName("my macro"))
        assertEquals("macro.json", MacroNaming.fileName("///"))
        assertEquals("ماکرو_من.json", MacroNaming.fileName("ماکرو من"))
        assertFalse(MacroNaming.fileName("a/b\\c").contains('/'))
    }

    @Test fun nameValidationBounds() {
        assertFalse(MacroNaming.isValidName("   "))
        assertTrue(MacroNaming.isValidName("x"))
        assertTrue(MacroNaming.isValidName("x".repeat(40)))
        assertFalse(MacroNaming.isValidName("x".repeat(41)))
    }
}
