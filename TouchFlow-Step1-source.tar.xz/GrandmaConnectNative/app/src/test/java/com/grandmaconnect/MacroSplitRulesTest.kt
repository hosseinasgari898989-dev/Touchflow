package com.grandmaconnect

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MacroSplitRulesTest {
    @Test fun addsSplitOnlyBetweenCompleteGroups() {
        assertEquals(listOf(2), MacroSplitRules.add(emptyList(), 4, 2))
        assertEquals(listOf(1, 2, 3), MacroSplitRules.add(listOf(1, 3), 4, 2))
    }

    @Test fun removingSplitDoesNotAffectOtherMarkers() {
        assertEquals(listOf(1, 3), MacroSplitRules.remove(listOf(1, 2, 3), 4, 2))
    }

    @Test fun rejectsStartEndDuplicateAndUnorderedMarkers() {
        assertFalse(MacroSplitRules.isValid(listOf(0), 4))
        assertFalse(MacroSplitRules.isValid(listOf(4), 4))
        assertFalse(MacroSplitRules.isValid(listOf(2, 2), 4))
        assertFalse(MacroSplitRules.isValid(listOf(3, 1), 4))
    }

    @Test fun rejectsAddingSplitAtInvalidOrExistingBoundary() {
        assertTrue(runCatching { MacroSplitRules.add(emptyList(), 4, 0) }.isFailure)
        assertTrue(runCatching { MacroSplitRules.add(listOf(2), 4, 2) }.isFailure)
    }
}
