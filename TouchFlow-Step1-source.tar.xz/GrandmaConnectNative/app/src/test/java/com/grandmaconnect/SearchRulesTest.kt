package com.grandmaconnect

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SearchRulesTest {
    @Test fun blankQueryMatchesEverything() {
        assertTrue(SearchRules.matches("", "x"))
        assertTrue(SearchRules.matches("   ", "x"))
    }

    @Test fun matchesCaseInsensitiveSubstring() {
        assertTrue(SearchRules.matches("tele", "Telegram"))
        assertFalse(SearchRules.matches("whats", "Telegram"))
    }

    @Test fun unifiesArabicAndPersianLetters() {
        assertTrue(SearchRules.matches("کتاب", "كتاب من"))
        assertTrue(SearchRules.matches("علی", "عليّ".replace("ّ", "")))
    }

    @Test fun unifiesDigitsAndIgnoresZwnj() {
        assertTrue(SearchRules.matches("۱۲", "ماکرو 12"))
        assertTrue(SearchRules.matches("می‌خواهم", "میخواهم"))
    }

    @Test fun allTokensMustMatchAcrossFields() {
        assertTrue(SearchRules.matches("چت تلگرام", "تلگرام", "org.telegram.chat"))
        assertFalse(SearchRules.matches("چت واتساپ", "تلگرام"))
    }

    @Test fun appPickerFilterKeepsOrderAndFindsByPackage() {
        val apps = listOf(
            AppPicker.App("a.b.camera", "دوربین"),
            AppPicker.App("c.d.maps", "نقشه"),
            AppPicker.App("e.f.cam2", "Camera Pro")
        )
        assertEquals(listOf("a.b.camera", "e.f.cam2"), AppPicker.filter(apps, "cam").map { it.packageName })
        assertEquals(listOf("c.d.maps"), AppPicker.filter(apps, "نقشه").map { it.packageName })
        assertTrue(AppPicker.filter(apps, "zzz").isEmpty())
    }
}
