package com.grandmaconnect

import android.accessibilityservice.GestureDescription
import android.content.Context

/** Hard safety ceilings stay active even when the user enables extended capacity. */
object MacroHardLimits {
    const val MAX_MACRO_DURATION_MS = 10 * 60 * 1000L
    const val MAX_GROUPS = 1_000
    const val MAX_POINTS_PER_STROKE = 5_000
    const val MAX_TOTAL_POINTS = 100_000
    const val MAX_STROKE_DURATION_MS = 60_000L
}

enum class CaptureQuality(
    val key: String,
    val title: String,
    val sampleIntervalMs: Long,
    val minPointDistanceDp: Float
) {
    ECONOMY("economy", "اقتصادی", 70L, 4f),
    BALANCED("balanced", "متعادل", 45L, 2f),
    PRECISE("precise", "دقیق", 16L, 1f);

    companion object {
        fun fromKey(value: String?): CaptureQuality = values().firstOrNull { it.key == value } ?: BALANCED
    }
}

data class MacroCaptureProfile(
    val extendedCapacity: Boolean,
    val maxMacroDurationMs: Long,
    val maxStrokeDurationMs: Long,
    val maxGroups: Int,
    val maxStrokesPerGroup: Int,
    val maxPointsPerStroke: Int,
    val maxTotalPoints: Int,
    val sampleIntervalMs: Long,
    val minPointDistanceDp: Float,
    val platformMaxGestureDurationMs: Long
)

object MacroSettingsStore {
    private const val PREFS_NAME = "macro_capture_settings"
    private const val KEY_EXTENDED_CAPACITY = "extended_capacity"
    private const val KEY_CAPTURE_QUALITY = "capture_quality"
    private const val KEY_EXTENDED_DURATION = "extended_duration_ms"

    const val DEFAULT_MACRO_DURATION_MS = 45_000L
    const val DEFAULT_STROKE_DURATION_MS = 8_000L
    const val DEFAULT_MAX_GROUPS = 200
    const val DEFAULT_MAX_POINTS_PER_STROKE = 1_500
    const val DEFAULT_MAX_TOTAL_POINTS = 12_000

    val extendedDurationsMs = listOf(2 * 60 * 1000L, 5 * 60 * 1000L, 10 * 60 * 1000L)

    fun load(context: Context): MacroCaptureProfile {
        val preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val extended = preferences.getBoolean(KEY_EXTENDED_CAPACITY, false)
        val quality = CaptureQuality.fromKey(preferences.getString(KEY_CAPTURE_QUALITY, CaptureQuality.BALANCED.key))
        val configuredDuration = preferences.getLong(KEY_EXTENDED_DURATION, 5 * 60 * 1000L)
            .takeIf { it in extendedDurationsMs }
            ?: 5 * 60 * 1000L
        val platformDuration = GestureDescription.getMaxGestureDuration()
            .coerceIn(1L, MacroHardLimits.MAX_STROKE_DURATION_MS)
        val platformStrokeCount = GestureDescription.getMaxStrokeCount().coerceAtLeast(1)

        return MacroCaptureProfile(
            extendedCapacity = extended,
            maxMacroDurationMs = if (extended) configuredDuration else DEFAULT_MACRO_DURATION_MS,
            maxStrokeDurationMs = if (extended) platformDuration else DEFAULT_STROKE_DURATION_MS.coerceAtMost(platformDuration),
            maxGroups = if (extended) MacroHardLimits.MAX_GROUPS else DEFAULT_MAX_GROUPS,
            maxStrokesPerGroup = platformStrokeCount,
            maxPointsPerStroke = if (extended) MacroHardLimits.MAX_POINTS_PER_STROKE else DEFAULT_MAX_POINTS_PER_STROKE,
            maxTotalPoints = if (extended) MacroHardLimits.MAX_TOTAL_POINTS else DEFAULT_MAX_TOTAL_POINTS,
            sampleIntervalMs = quality.sampleIntervalMs,
            minPointDistanceDp = quality.minPointDistanceDp,
            platformMaxGestureDurationMs = platformDuration
        )
    }

    fun save(context: Context, extendedCapacity: Boolean, quality: CaptureQuality, extendedDurationMs: Long) {
        require(extendedDurationMs in extendedDurationsMs) { "مدت انتخاب‌شده پشتیبانی نمی‌شود." }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_EXTENDED_CAPACITY, extendedCapacity)
            .putString(KEY_CAPTURE_QUALITY, quality.key)
            .putLong(KEY_EXTENDED_DURATION, extendedDurationMs)
            .apply()
    }

    fun describeDuration(durationMs: Long): String = when {
        durationMs < 60_000L -> "${durationMs / 1000L} ثانیه"
        durationMs % 60_000L == 0L -> "${durationMs / 60_000L} دقیقه"
        else -> "${durationMs / 60_000L} دقیقه و ${(durationMs % 60_000L) / 1000L} ثانیه"
    }
}
