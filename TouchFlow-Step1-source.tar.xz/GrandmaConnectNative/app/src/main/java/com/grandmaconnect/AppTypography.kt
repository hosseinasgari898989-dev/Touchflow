package com.grandmaconnect

import android.content.Context
import android.graphics.Typeface
import android.os.Build

/** Central typography. Replace the three font files in res/font to change the app font. */
object AppTypography {
    enum class Weight { REGULAR, MEDIUM, BOLD }

    fun typeface(context: Context, weight: Weight): Typeface {
        if (Build.VERSION.SDK_INT >= 26) {
            val res = when (weight) {
                Weight.REGULAR -> R.font.vazirmatn_regular
                Weight.MEDIUM -> R.font.vazirmatn_medium
                Weight.BOLD -> R.font.vazirmatn_bold
            }
            try {
                return context.resources.getFont(res)
            } catch (_: Exception) {
                // fall through to the system font
            }
        }
        return when (weight) {
            Weight.REGULAR -> Typeface.SANS_SERIF
            Weight.MEDIUM -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            Weight.BOLD -> Typeface.create("sans-serif", Typeface.BOLD)
        }
    }
}
