package com.grandmaconnect

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Searchable picker for launchable apps. Uses only the launcher-intent <queries>; no QUERY_ALL_PACKAGES. */
object AppPicker {
    data class App(val packageName: String, val label: String)

    fun load(context: Context): List<App> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return resolved.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == context.packageName) return@mapNotNull null
            val label = info.loadLabel(pm)?.toString()?.trim().orEmpty()
            if (label.isBlank()) null else App(pkg, label)
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    fun filter(apps: List<App>, query: String): List<App> =
        apps.filter { SearchRules.matches(query, it.label, it.packageName) }

    fun show(activity: Activity, title: String, onPick: (App) -> Unit) {
        val all = load(activity)
        if (all.isEmpty()) {
            android.widget.Toast.makeText(activity, "برنامه قابل‌بازکردنی پیدا نشد.", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val regular = AppTypography.typeface(activity, AppTypography.Weight.REGULAR)

        val search = EditText(activity).apply {
            hint = "جستجوی نام برنامه"
            typeface = regular
            setSingleLine()
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            textDirection = View.TEXT_DIRECTION_LOCALE
        }
        val empty = TextView(activity).apply {
            text = "برنامه‌ای با این نام پیدا نشد."
            typeface = regular
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, dp(24))
            visibility = View.GONE
        }
        val list = ListView(activity).apply { divider = null }
        val shown = all.toMutableList()
        val iconCache = HashMap<String, Drawable?>()
        val adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(position: Int) = shown[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val app = shown[position]
                val row = LinearLayout(activity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                val icon = ImageView(activity).apply {
                    val drawable = iconCache.getOrPut(app.packageName) {
                        try { activity.packageManager.getApplicationIcon(app.packageName) } catch (_: Exception) { null }
                    }
                    setImageDrawable(drawable)
                }
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                row.addView(TextView(activity).apply {
                    text = app.label
                    typeface = regular
                    textSize = 16f
                    setTextColor(Color.rgb(27, 43, 64))
                    setPadding(dp(12), 0, dp(12), 0)
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                return row
            }
        }
        list.adapter = adapter

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(8), dp(16), 0)
            addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(empty)
            addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(320)))
        }
        val dialog = AlertDialog.Builder(activity)
            .setTitle(title)
            .setView(root)
            .setNegativeButton("لغو", null)
            .create()
        list.setOnItemClickListener { _, _, position, _ ->
            val app = shown[position]
            dialog.dismiss()
            onPick(app)
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                shown.clear()
                shown.addAll(filter(all, s?.toString().orEmpty()))
                adapter.notifyDataSetChanged()
                empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
                list.visibility = if (shown.isEmpty()) View.GONE else View.VISIBLE
            }
        })
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        dialog.show()
    }
}
