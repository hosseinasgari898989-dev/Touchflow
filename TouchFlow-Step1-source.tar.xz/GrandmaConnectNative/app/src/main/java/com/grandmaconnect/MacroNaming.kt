package com.grandmaconnect

/** Pure naming helpers (unit-testable). */
object MacroNaming {
    const val MAX_NAME = 40
    private const val COPY_SUFFIX = " (کپی)"

    fun copyName(name: String): String {
        val base = name.trim()
        val room = MAX_NAME - COPY_SUFFIX.length
        return (if (base.length > room) base.take(room).trimEnd() else base) + COPY_SUFFIX
    }

    /** Safe file name for exports: letters, digits, '_' and '-' only; never empty. */
    fun fileName(name: String, extension: String = "json"): String {
        val cleaned = name.trim().replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").trim('_').take(40)
        return (cleaned.ifEmpty { "macro" }) + "." + extension
    }

    fun isValidName(name: String): Boolean = name.trim().length in 1..MAX_NAME
}
