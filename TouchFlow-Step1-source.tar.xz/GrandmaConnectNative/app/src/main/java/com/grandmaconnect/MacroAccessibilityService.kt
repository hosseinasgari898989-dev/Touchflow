package com.grandmaconnect

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class MacroAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: MacroAccessibilityService? = null
            private set

        fun isEnabledInSettings(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val component = ComponentName(context, MacroAccessibilityService::class.java).flattenToString()
            return enabled.split(':').any { it.equals(component, ignoreCase = true) }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var stopRequested = false
    @Volatile private var playing = false
    private var currentMacroName = ""
    @Volatile private var paused = false
    private var heldStep: (() -> Unit)? = null
    private var heldRemainingMs = 0L
    private var scheduledRunnable: Runnable? = null
    private var scheduledStep: (() -> Unit)? = null
    private var scheduledDueAt = 0L
    private var currentGroupIndex = 0
    private var totalGroups = 0

    val isPlaying: Boolean get() = playing
    val isPaused: Boolean get() = playing && paused
    private var currentNotificationId = 701
    private val channelId = "touchflow_macro_playback"

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        createNotificationChannel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally does not inspect, read or store other apps' screen content.
    }

    override fun onInterrupt() {
        stopPlayback()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        resetRunState()
        if (playing) {
            playing = false
            stopRequested = true
            cancelNotification()
        }
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun playMacro(macro: TouchMacro, initialDelayMs: Long = 3_000L) {
        if (playing) throw IllegalStateException("یک ماکرو در حال اجراست.")
        MacroStore.validate(macro)
        require(initialDelayMs in 0L..10_000L) { "زمان شروع نامعتبر است." }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            throw IllegalStateException("اجازه اعلان توقف فعال نیست.")
        }
        val displayMetrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(displayMetrics)
        val recordedPortrait = macro.recordedScreenHeight >= macro.recordedScreenWidth
        val currentPortrait = displayMetrics.heightPixels >= displayMetrics.widthPixels
        require(recordedPortrait == currentPortrait) { "جهت صفحه با زمان ضبط فرق دارد." }
        resetRunState()
        playing = true
        stopRequested = false
        currentMacroName = macro.name
        totalGroups = macro.groups.size
        currentGroupIndex = 0
        showNotification("شروع تا ${initialDelayMs / 1000.0} ثانیه دیگر؛ توقف از اعلان در دسترس است")
        schedule(initialDelayMs) {
            if (stopRequested) {
                finishStopped()
            } else {
                runActionsAtBoundary(macro, 0) {
                    val firstStart = macro.groups.firstOrNull()?.startOffsetMs ?: 0L
                    schedule(firstStart) { dispatchGroup(macro, 0) }
                }
            }
        }
    }

    /** Runs [step] after [delayMs]; if paused it is held with its full remaining delay until resume. */
    private fun schedule(delayMs: Long, step: () -> Unit) {
        val d = delayMs.coerceAtLeast(0L)
        if (paused) {
            heldStep = step
            heldRemainingMs = d
            return
        }
        scheduledStep = step
        scheduledDueAt = SystemClock.uptimeMillis() + d
        val runnable = Runnable {
            scheduledRunnable = null
            val next = scheduledStep
            scheduledStep = null
            next?.invoke()
        }
        scheduledRunnable = runnable
        handler.postDelayed(runnable, d)
    }

    private fun resetRunState() {
        scheduledRunnable?.let { handler.removeCallbacks(it) }
        scheduledRunnable = null
        scheduledStep = null
        heldStep = null
        heldRemainingMs = 0L
        paused = false
    }

    /** Pause keeps the exact next step and its remaining delay; a touch already in flight may finish first. */
    fun pausePlayback() {
        if (!playing || paused || stopRequested) return
        paused = true
        val pending = scheduledRunnable
        if (pending != null) {
            handler.removeCallbacks(pending)
            scheduledRunnable = null
            heldStep = scheduledStep
            scheduledStep = null
            heldRemainingMs = (scheduledDueAt - SystemClock.uptimeMillis()).coerceAtLeast(0L)
        }
        updateNotification("مکث شد · بخش ${currentGroupIndex + 1} از $totalGroups")
    }

    fun resumePlayback() {
        if (!playing || !paused) return
        paused = false
        updateNotification("ادامهٔ اجرا · بخش ${currentGroupIndex + 1} از $totalGroups")
        val step = heldStep
        heldStep = null
        if (step != null) schedule(heldRemainingMs, step)
    }

    fun stopPlayback() {
        if (!playing) return
        stopRequested = true
        val waiting = paused || scheduledRunnable != null
        if (waiting) {
            // Nothing is touching the screen right now: stop immediately.
            resetRunState()
            finishStopped()
            return
        }
        updateNotification("درخواست توقف ثبت شد؛ حرکت لمسی جاری ممکن است کامل شود")
    }

    private fun dispatchGroup(macro: TouchMacro, index: Int) {
        if (stopRequested) return finishStopped()
        if (index >= macro.groups.size) return finishCompleted()
        if (!isOrientationCompatible(macro)) {
            return finishFailed("جهت صفحه هنگام اجرای ماکرو تغییر کرد؛ برای جلوگیری از لمس اشتباه، اجرا متوقف شد.")
        }

        currentGroupIndex = index
        val group = macro.groups[index]
        val gesture = try {
            buildGesture(group)
        } catch (error: Exception) {
            return finishFailed("ساخت حرکت ناموفق بود: ${error.message ?: "خطای نامشخص"}")
        }

        updateNotification("در حال اجرای بخش ${index + 1} از ${macro.groups.size}")
        val dispatched = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                if (stopRequested) return finishStopped()
                val completedGroupCount = index + 1
                val currentEnd = group.startOffsetMs +
                    (group.strokes.maxOfOrNull { it.startOffsetMs + it.durationMs } ?: 0L)
                val nextStart = macro.groups.getOrNull(index + 1)?.startOffsetMs ?: currentEnd
                val naturalGap = (nextStart - currentEnd).coerceAtLeast(0L)

                runActionsAtBoundary(macro, completedGroupCount) {
                    if (stopRequested) return@runActionsAtBoundary finishStopped()
                    if (index + 1 >= macro.groups.size) {
                        finishCompleted()
                    } else {
                        val actionWait = macro.actions
                            .filter { it.afterGroupCount == completedGroupCount }
                            .sumOf { it.waitAfterMs }
                        val remainingGap = (naturalGap - actionWait).coerceAtLeast(0L)
                        schedule(remainingGap) { dispatchGroup(macro, index + 1) }
                    }
                }
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                finishFailed("اجرای لمس توسط اندروید لغو شد.")
            }
        }, handler)

        if (!dispatched) finishFailed("اندروید اجرای این حرکت را نپذیرفت.")
    }

    /** Run explicit user-configured actions between touch groups, in saved order. */
    private fun runActionsAtBoundary(macro: TouchMacro, afterGroupCount: Int, onDone: () -> Unit) {
        val actions = macro.actions.filter { it.afterGroupCount == afterGroupCount }
        runActionAtIndex(actions, 0, onDone)
    }

    private fun runActionAtIndex(actions: List<MacroFlowAction>, index: Int, onDone: () -> Unit) {
        if (stopRequested) return finishStopped()
        if (index >= actions.size) return onDone()
        val action = actions[index]
        try {
            when (action.type) {
                MacroActionType.LAUNCH_APP -> {
                    val launchIntent = packageManager.getLaunchIntentForPackage(action.packageName)
                        ?: return finishFailed("برنامه «${action.appLabel}» نصب نیست یا راه‌اندازی آن در دسترس نیست.")
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(launchIntent)
                    updateNotification("درخواست بازکردن «${action.appLabel}» ارسال شد")
                }
                MacroActionType.GO_HOME -> {
                    if (!performGlobalAction(GLOBAL_ACTION_HOME)) {
                        return finishFailed("اندروید فرمان رفتن به صفحه اصلی را نپذیرفت.")
                    }
                    updateNotification("در حال رفتن به صفحه اصلی")
                }
                MacroActionType.GO_BACK -> {
                    if (!performGlobalAction(GLOBAL_ACTION_BACK)) {
                        return finishFailed("اندروید فرمان بازگشت را نپذیرفت.")
                    }
                    updateNotification("در حال بازگشت به صفحه قبلی")
                }
                MacroActionType.GO_RECENTS -> {
                    if (!performGlobalAction(GLOBAL_ACTION_RECENTS)) {
                        return finishFailed("اندروید فرمان برنامه‌های اخیر را نپذیرفت.")
                    }
                    updateNotification("در حال بازکردن برنامه‌های اخیر")
                }
                MacroActionType.OPEN_INTERNET_PANEL -> {
                    // Android does not let normal apps switch Wi-Fi/mobile data silently; the user does it in the system panel.
                    val panel = if (Build.VERSION.SDK_INT >= 29) {
                        Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                    } else {
                        Intent(Settings.ACTION_WIFI_SETTINGS)
                    }
                    panel.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(panel)
                    updateNotification("پنل اینترنت باز شد؛ تغییر را خودت انجام بده")
                }
            }
        } catch (error: Exception) {
            val actionName = when (action.type) {
                MacroActionType.LAUNCH_APP -> action.appLabel
                MacroActionType.GO_HOME -> "صفحه اصلی"
                MacroActionType.GO_BACK -> "بازگشت"
                MacroActionType.GO_RECENTS -> "برنامه‌های اخیر"
                MacroActionType.OPEN_INTERNET_PANEL -> "پنل اینترنت"
            }
            return finishFailed("اجرای اقدام «$actionName» ناموفق بود.")
        }
        schedule(action.waitAfterMs) { runActionAtIndex(actions, index + 1, onDone) }
    }

    private fun isOrientationCompatible(macro: TouchMacro): Boolean {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val recordedPortrait = macro.recordedScreenHeight >= macro.recordedScreenWidth
        val currentPortrait = metrics.heightPixels >= metrics.widthPixels
        return recordedPortrait == currentPortrait
    }

    private fun buildGesture(group: MacroGestureGroup): GestureDescription {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val builder = GestureDescription.Builder()
        group.strokes.forEach { stroke ->
            val first = stroke.points.first()
            val path = Path().apply {
                moveTo(first.x * metrics.widthPixels, first.y * metrics.heightPixels)
                stroke.points.drop(1).forEach { point ->
                    lineTo(point.x * metrics.widthPixels, point.y * metrics.heightPixels)
                }
                if (stroke.points.size == 1) lineTo(first.x * metrics.widthPixels, first.y * metrics.heightPixels)
            }
            builder.addStroke(GestureDescription.StrokeDescription(path, stroke.startOffsetMs, stroke.durationMs))
        }
        return builder.build()
    }

    private fun finishStopped() {
        if (!playing) return
        resetRunState()
        playing = false
        updateNotification("ماکرو متوقف شد")
        handler.postDelayed({ cancelNotification() }, 3_000L)
    }

    private fun finishCompleted() {
        if (!playing) return
        resetRunState()
        playing = false
        updateNotification("اجرای ماکرو تمام شد")
        handler.postDelayed({ cancelNotification() }, 4_000L)
    }

    private fun finishFailed(message: String) {
        if (!playing) return
        resetRunState()
        playing = false
        stopRequested = true
        updateNotification(message)
        handler.postDelayed({ cancelNotification() }, 7_000L)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "وضعیت اجرای TouchFlow", NotificationManager.IMPORTANCE_LOW)
            channel.description = "وضعیت و توقف ماکروهای انتخاب‌شده توسط کاربر"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun actionPending(code: Int, action: String): PendingIntent = PendingIntent.getBroadcast(
        this, code,
        Intent(this, StopPlaybackReceiver::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildNotification(message: String, ongoing: Boolean): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        builder
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("TouchFlow · $currentMacroName")
            .setContentText(message)
            .setOngoing(ongoing)
        if (playing && !stopRequested) {
            if (paused) {
                builder.addAction(Notification.Action.Builder(null, "ادامه", actionPending(704, StopPlaybackReceiver.ACTION_RESUME)).build())
            } else {
                builder.addAction(Notification.Action.Builder(null, "مکث", actionPending(703, StopPlaybackReceiver.ACTION_PAUSE)).build())
            }
        }
        builder.addAction(Notification.Action.Builder(null, "توقف فوری", actionPending(702, StopPlaybackReceiver.ACTION_STOP)).build())
        return builder.build()
    }

    private fun showNotification(message: String) = updateNotification(message)

    private fun updateNotification(message: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(currentNotificationId, buildNotification(message, playing))
        } catch (_: SecurityException) {
            // The UI requests notification permission before playback on Android 13+.
        }
    }

    private fun cancelNotification() {
        getSystemService(NotificationManager::class.java).cancel(currentNotificationId)
    }
}

class StopPlaybackReceiver : android.content.BroadcastReceiver() {
    companion object {
        const val ACTION_STOP = "com.grandmaconnect.STOP_PLAYBACK"
        const val ACTION_PAUSE = "com.grandmaconnect.PAUSE_PLAYBACK"
        const val ACTION_RESUME = "com.grandmaconnect.RESUME_PLAYBACK"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val service = MacroAccessibilityService.instance ?: return
        when (intent?.action) {
            ACTION_PAUSE -> service.pausePlayback()
            ACTION_RESUME -> service.resumePlayback()
            else -> service.stopPlayback()
        }
    }
}
