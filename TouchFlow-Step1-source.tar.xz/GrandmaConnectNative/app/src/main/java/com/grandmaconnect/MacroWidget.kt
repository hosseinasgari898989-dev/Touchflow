package com.grandmaconnect

import android.app.Activity
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.RemoteViews
import android.widget.TextView
import android.widget.Toast

object MacroWidgetContract {
    const val ACTION_HELP = "com.grandmaconnect.widget.HELP"
    const val EXTRA_MESSAGE = "com.grandmaconnect.widget.MESSAGE"
    const val EXTRA_NEEDS_ACCESSIBILITY = "com.grandmaconnect.widget.NEEDS_ACCESSIBILITY"
    const val EXTRA_NEEDS_NOTIFICATIONS = "com.grandmaconnect.widget.NEEDS_NOTIFICATIONS"
    /** Old versions bound one macro per widget; that binding is no longer used and is cleared. */
    const val LEGACY_PREFS = "macro_widget_assignments"
}

/** Widget never stores a macro: every tap opens [MacroPickerActivity]. */
class MacroWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        context.getSharedPreferences(MacroWidgetContract.LEGACY_PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        appWidgetIds.forEach { MacroWidgetRenderer.update(context, manager, it) }
    }
}

object MacroWidgetRenderer {
    fun update(context: Context, manager: AppWidgetManager, widgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_macro)
        views.setTextViewText(R.id.widget_title, "TouchFlow")
        views.setTextViewText(R.id.widget_subtitle, "برای انتخاب و اجرای ماکرو لمس کن")
        val pickIntent = Intent(context, MacroPickerActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pending = PendingIntent.getActivity(
            context, widgetId, pickIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_root, pending)
        manager.updateAppWidget(widgetId, views)
    }
}

object MacroWidgetLauncher {
    class Failure(val message: String, val needsAccessibility: Boolean = false, val needsNotifications: Boolean = false)

    /** Returns null when playback was accepted, otherwise the reason it did not start. */
    fun start(context: Context, macro: TouchMacro): Failure? {
        return try {
            MacroStore.validate(macro)
            if (!MacroAccessibilityService.isEnabledInSettings(context)) {
                return Failure("برای اجرای ماکرو، ابتدا سرویس دسترس‌پذیری TouchFlow را فعال کن.", needsAccessibility = true)
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                return Failure("برای اینکه توقف ماکرو همیشه در دسترس باشد، اجازه اعلان را فعال کن.", needsNotifications = true)
            }
            val service = MacroAccessibilityService.instance
                ?: return Failure("سرویس هنوز آماده نشده است؛ چند ثانیه بعد دوباره امتحان کن.", needsAccessibility = true)
            service.playMacro(macro, initialDelayMs = 0L)
            null
        } catch (error: Exception) {
            Failure("اجرای ماکرو شروع نشد: ${error.message ?: "خطای نامشخص"}")
        }
    }
}

/** Dialog-style chooser shown on EVERY widget tap. Closes itself as soon as playback is accepted. */
class MacroPickerActivity : Activity() {
    private data class Row(val id: String, val name: String, val detail: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()
        val regular = AppTypography.typeface(this, AppTypography.Weight.REGULAR)
        val bold = AppTypography.typeface(this, AppTypography.Weight.BOLD)

        val macros = try { MacroStore.loadAll(this) } catch (_: Exception) { emptyList() }
        val all = macros.map {
            Row(it.id, it.name, "${it.groups.size} بخش لمس · ${"%.1f".format(it.totalDurationMs / 1000.0)} ثانیه")
        }
        val shown = all.toMutableList()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(18), dp(20), dp(12))
        }
        root.addView(TextView(this).apply {
            text = "کدام ماکرو اجرا شود؟"
            typeface = bold
            textSize = 19f
            setTextColor(Color.rgb(27, 43, 64))
            gravity = Gravity.START
        })

        if (all.isEmpty()) {
            root.addView(TextView(this).apply {
                text = "هنوز ماکرویی ذخیره نشده. ابتدا در TouchFlow یک ماکرو ضبط و ذخیره کن."
                typeface = regular
                textSize = 15f
                setPadding(0, dp(14), 0, dp(14))
            })
            root.addView(Button(this).apply {
                text = "بازکردن TouchFlow"
                typeface = regular
                isAllCaps = false
                setOnClickListener {
                    startActivity(Intent(this@MacroPickerActivity, MainActivity::class.java))
                    finish()
                }
            })
        } else {
            val search = EditText(this).apply {
                hint = "جستجوی ماکرو"
                typeface = regular
                setSingleLine()
            }
            val empty = TextView(this).apply {
                text = "ماکرویی با این نام پیدا نشد."
                typeface = regular
                gravity = Gravity.CENTER
                setPadding(0, dp(24), 0, dp(24))
                visibility = View.GONE
            }
            val list = ListView(this).apply { divider = null }
            val adapter = object : BaseAdapter() {
                override fun getCount() = shown.size
                override fun getItem(position: Int) = shown[position]
                override fun getItemId(position: Int) = position.toLong()
                override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                    val item = shown[position]
                    return LinearLayout(this@MacroPickerActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        layoutDirection = View.LAYOUT_DIRECTION_RTL
                        setPadding(dp(8), dp(10), dp(8), dp(10))
                        addView(TextView(context).apply {
                            text = item.name; typeface = bold; textSize = 16f
                            setTextColor(Color.rgb(27, 43, 64))
                        })
                        addView(TextView(context).apply {
                            text = item.detail; typeface = regular; textSize = 12f
                            setTextColor(Color.rgb(79, 91, 107))
                        })
                    }
                }
            }
            list.adapter = adapter
            list.setOnItemClickListener { _, _, position, _ -> startSelected(shown[position].id) }
            search.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    shown.clear()
                    shown.addAll(all.filter { SearchRules.matches(s?.toString().orEmpty(), it.name) })
                    adapter.notifyDataSetChanged()
                    empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
                    list.visibility = if (shown.isEmpty()) View.GONE else View.VISIBLE
                }
            })
            root.addView(search)
            root.addView(empty)
            root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)))
        }
        root.addView(Button(this).apply {
            text = "لغو"
            typeface = regular
            isAllCaps = false
            setOnClickListener { finish() }
        })
        setContentView(root)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }

    private fun startSelected(macroId: String) {
        // Re-read from storage: the macro may have been deleted since the list was built.
        val macro = try { MacroStore.loadAll(this).firstOrNull { it.id == macroId } } catch (_: Exception) { null }
        if (macro == null) {
            Toast.makeText(this, "این ماکرو دیگر وجود ندارد.", Toast.LENGTH_LONG).show()
            return
        }
        val failure = MacroWidgetLauncher.start(this, macro)
        if (failure == null) {
            finish()
            return
        }
        if (failure.needsAccessibility || failure.needsNotifications) {
            val help = Intent(this, MainActivity::class.java)
                .setAction(MacroWidgetContract.ACTION_HELP)
                .putExtra(MacroWidgetContract.EXTRA_MESSAGE, failure.message)
                .putExtra(MacroWidgetContract.EXTRA_NEEDS_ACCESSIBILITY, failure.needsAccessibility)
                .putExtra(MacroWidgetContract.EXTRA_NEEDS_NOTIFICATIONS, failure.needsNotifications)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            startActivity(help)
            finish()
        } else {
            Toast.makeText(this, failure.message, Toast.LENGTH_LONG).show()
        }
    }
}
