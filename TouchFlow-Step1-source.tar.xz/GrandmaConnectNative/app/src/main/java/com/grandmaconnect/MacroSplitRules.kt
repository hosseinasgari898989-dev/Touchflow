package com.grandmaconnect

/** Pure timeline rules: split markers always sit between complete gesture groups. */
object MacroSplitRules {
    fun isValid(markers: List<Int>, groupCount: Int): Boolean {
        if (groupCount < 0) return false
        if (markers.any { it !in 1 until groupCount }) return false
        if (markers.distinct().size != markers.size) return false
        return markers.zipWithNext().all { (left, right) -> left < right }
    }

    fun add(markers: List<Int>, groupCount: Int, afterGroupCount: Int): List<Int> {
        require(isValid(markers, groupCount)) { "نشانگرهای برش فعلی نامعتبرند." }
        require(afterGroupCount in 1 until groupCount) { "برش فقط بین دو بخش کامل لمس مجاز است." }
        require(afterGroupCount !in markers) { "در این محل از قبل برش وجود دارد." }
        return (markers + afterGroupCount).sorted()
    }

    fun remove(markers: List<Int>, groupCount: Int, afterGroupCount: Int): List<Int> {
        require(isValid(markers, groupCount)) { "نشانگرهای برش فعلی نامعتبرند." }
        return markers.filterNot { it == afterGroupCount }
    }
}
