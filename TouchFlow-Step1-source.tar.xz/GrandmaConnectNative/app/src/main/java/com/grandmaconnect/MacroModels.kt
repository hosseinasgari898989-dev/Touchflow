package com.grandmaconnect

import android.accessibilityservice.GestureDescription
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Coordinates are normalized against the complete physical display (0.0..1.0). */
data class NormalizedPoint(val x: Float, val y: Float)
data class MacroStroke(val startOffsetMs: Long, val durationMs: Long, val points: List<NormalizedPoint>)
data class MacroGestureGroup(val startOffsetMs: Long, val strokes: List<MacroStroke>)

/** GO_RECENTS and OPEN_INTERNET_PANEL were added later; old files stay readable, old app versions cannot read macros that use them. */
enum class MacroActionType { LAUNCH_APP, GO_HOME, GO_BACK, GO_RECENTS, OPEN_INTERNET_PANEL }

/**
 * A native action inserted between recorded touch groups.
 * afterGroupCount=0 means before the first touch group; N means after N completed groups.
 */
data class MacroFlowAction(
    val id: String,
    val afterGroupCount: Int,
    val type: MacroActionType,
    val packageName: String = "",
    val appLabel: String = "",
    val waitAfterMs: Long = 2_500L
)

data class TouchMacro(
    val id: String,
    val name: String,
    val createdAt: Long,
    val recordedScreenWidth: Int,
    val recordedScreenHeight: Int,
    val totalDurationMs: Long,
    val groups: List<MacroGestureGroup>,
    val actions: List<MacroFlowAction> = emptyList(),
    /** Split markers are counts of complete gesture groups before each cut. */
    val splitAfterGroupCounts: List<Int> = emptyList()
)

/**
 * Schemas 1 and 2 remain readable. Schema 3 adds timeline split markers without
 * changing recorded groups or ordered app/navigation actions.
 */
object MacroStore {
    private const val CURRENT_SCHEMA_VERSION = 3
    private val supportedSchemas = setOf(1, 2, 3)
    const val MAX_MACRO_DURATION_MS = MacroHardLimits.MAX_MACRO_DURATION_MS
    const val MAX_ACTIONS = 200

    private fun folder(context: Context): File = File(context.filesDir, "macros").apply { mkdirs() }

    fun save(context: Context, macro: TouchMacro) {
        validate(macro)
        require(macro.name.trim().isNotEmpty()) { "نام ماکرو خالی است." }
        val dir = folder(context)
        val target = File(dir, "${macro.id}.json")
        val temp = File(dir, "${macro.id}.json.tmp")
        temp.writeText(toJson(macro).toString(), Charsets.UTF_8)
        if (!temp.renameTo(target)) {
            temp.copyTo(target, overwrite = true)
            if (!temp.delete()) temp.deleteOnExit()
        }
    }

    fun loadAll(context: Context): List<TouchMacro> {
        val dir = folder(context)
        return dir.listFiles { file -> file.isFile && file.extension == "json" }
            ?.mapNotNull { file ->
                try {
                    fromJson(JSONObject(file.readText(Charsets.UTF_8))).also(::validate)
                } catch (_: Exception) {
                    null
                }
            }
            ?.sortedByDescending { it.createdAt }
            ?: emptyList()
    }

    fun delete(context: Context, id: String): Boolean {
        if (!id.matches(Regex("[A-Za-z0-9_-]{1,80}"))) return false
        val file = File(folder(context), "$id.json")
        return !file.exists() || file.delete()
    }

    fun validate(macro: TouchMacro) {
        require(macro.id.matches(Regex("[A-Za-z0-9_-]{1,80}"))) { "شناسه ماکرو نامعتبر است." }
        require(macro.name.trim().length in 1..40) { "نام ماکرو باید بین ۱ تا ۴۰ نویسه باشد." }
        require(macro.recordedScreenWidth in 200..10000 && macro.recordedScreenHeight in 200..20000) {
            "اندازه صفحه ضبط‌شده نامعتبر است."
        }
        require(macro.groups.isNotEmpty() && macro.groups.size <= MacroHardLimits.MAX_GROUPS) {
            "تعداد حرکت‌ها از سقف ایمنی برنامه بیشتر است."
        }
        require(macro.totalDurationMs in 1..MAX_MACRO_DURATION_MS) {
            "مدت ماکرو از سقف ایمنی ۱۰ دقیقه‌ای برنامه بیشتر است."
        }

        val platformGestureDuration = GestureDescription.getMaxGestureDuration().toLong()
        val platformStrokeCount = GestureDescription.getMaxStrokeCount()
        var points = 0
        var previousStart = -1L

        for (group in macro.groups) {
            require(group.startOffsetMs in 0 until macro.totalDurationMs) { "زمان شروع یک حرکت نامعتبر است." }
            require(group.startOffsetMs >= previousStart) { "ترتیب حرکت‌ها نامعتبر است." }
            previousStart = group.startOffsetMs
            require(group.strokes.isNotEmpty() && group.strokes.size <= platformStrokeCount) {
                "تعداد انگشت‌های هم‌زمان از سقف پشتیبانی‌شده اندروید بیشتر است."
            }

            for (stroke in group.strokes) {
                require(stroke.startOffsetMs >= 0L) { "زمان شروع لمس نامعتبر است." }
                require(stroke.durationMs in 1..platformGestureDuration) { "مدت یک لمس از سقف اندروید بیشتر است." }
                require(stroke.startOffsetMs + stroke.durationMs <= platformGestureDuration) {
                    "مدت یک گروه لمس از سقف اندروید بیشتر است."
                }
                require(group.startOffsetMs + stroke.startOffsetMs + stroke.durationMs <= macro.totalDurationMs + 50L) {
                    "زمان حرکت خارج از محدوده طول ماکرو است."
                }
                require(stroke.points.isNotEmpty() && stroke.points.size <= MacroHardLimits.MAX_POINTS_PER_STROKE) {
                    "تعداد نقاط یک حرکت از سقف ایمنی برنامه بیشتر است."
                }
                points += stroke.points.size
                require(points <= MacroHardLimits.MAX_TOTAL_POINTS) { "تعداد کل نقاط از سقف ایمنی برنامه بیشتر است." }
                stroke.points.forEach { point ->
                    require(point.x.isFinite() && point.y.isFinite() && point.x in 0f..1f && point.y in 0f..1f) {
                        "مختصات لمس نامعتبر است."
                    }
                }
            }
        }

        require(macro.actions.size <= MAX_ACTIONS) { "تعداد اقدامات خودکار از سقف مجاز بیشتر است." }
        require(macro.actions.map { it.id }.distinct().size == macro.actions.size) { "شناسه اقدامات تکراری است." }
        val totalActionWaitMs = macro.actions.sumOf { it.waitAfterMs }
        require(macro.totalDurationMs + totalActionWaitMs <= MAX_MACRO_DURATION_MS) {
            "مدت حرکت‌ها به‌همراه مکث‌های خودکار نباید از ۱۰ دقیقه بیشتر شود."
        }
        macro.actions.forEach { action ->
            require(action.id.matches(Regex("[A-Za-z0-9_-]{1,80}"))) { "شناسه اقدام نامعتبر است." }
            require(action.afterGroupCount in 0..macro.groups.size) { "محل اجرای اقدام در ماکرو معتبر نیست." }
            require(action.waitAfterMs in 0L..60_000L) { "مدت مکث پس از اقدام نامعتبر است." }
            when (action.type) {
                MacroActionType.LAUNCH_APP -> {
                    require(action.packageName.matches(Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+"))) {
                        "شناسه برنامه برای بازکردن معتبر نیست."
                    }
                    require(action.appLabel.trim().length in 1..100) { "نام برنامه معتبر نیست." }
                }
                MacroActionType.GO_HOME, MacroActionType.GO_BACK, MacroActionType.GO_RECENTS, MacroActionType.OPEN_INTERNET_PANEL -> {
                    require(action.packageName.isEmpty()) { "اقدام ناوبری نباید شناسه برنامه داشته باشد." }
                    require(action.appLabel.isEmpty()) { "اقدام ناوبری نباید نام برنامه داشته باشد." }
                }
            }
        }
        require(MacroSplitRules.isValid(macro.splitAfterGroupCounts, macro.groups.size)) {
            "نشانگرهای برش باید یکتا و فقط بین دو بخش کامل لمس باشند."
        }
    }

    private fun toJson(macro: TouchMacro): JSONObject {
        val groupsJson = JSONArray()
        macro.groups.forEach { group ->
            val strokesJson = JSONArray()
            group.strokes.forEach { stroke ->
                val pointsJson = JSONArray()
                stroke.points.forEach { point ->
                    pointsJson.put(JSONObject().put("x", point.x.toDouble()).put("y", point.y.toDouble()))
                }
                strokesJson.put(
                    JSONObject()
                        .put("startOffsetMs", stroke.startOffsetMs)
                        .put("durationMs", stroke.durationMs)
                        .put("points", pointsJson)
                )
            }
            groupsJson.put(JSONObject().put("startOffsetMs", group.startOffsetMs).put("strokes", strokesJson))
        }

        val actionsJson = JSONArray()
        macro.actions.forEach { action ->
            actionsJson.put(
                JSONObject()
                    .put("id", action.id)
                    .put("afterGroupCount", action.afterGroupCount)
                    .put("type", action.type.name)
                    .put("packageName", action.packageName)
                    .put("appLabel", action.appLabel)
                    .put("waitAfterMs", action.waitAfterMs)
            )
        }

        return JSONObject()
            .put("schemaVersion", CURRENT_SCHEMA_VERSION)
            .put("id", macro.id)
            .put("name", macro.name)
            .put("createdAt", macro.createdAt)
            .put("recordedScreenWidth", macro.recordedScreenWidth)
            .put("recordedScreenHeight", macro.recordedScreenHeight)
            .put("totalDurationMs", macro.totalDurationMs)
            .put("groups", groupsJson)
            .put("actions", actionsJson)
            .put("splitAfterGroupCounts", JSONArray().apply {
                macro.splitAfterGroupCounts.forEach { marker -> put(marker) }
            })
    }

    private fun fromJson(json: JSONObject): TouchMacro {
        val version = json.optInt("schemaVersion", -1)
        require(version in supportedSchemas) { "نسخه فایل ماکرو پشتیبانی نمی‌شود." }
        val groupsArray = json.getJSONArray("groups")
        val groups = ArrayList<MacroGestureGroup>(groupsArray.length())
        for (i in 0 until groupsArray.length()) {
            val groupJson = groupsArray.getJSONObject(i)
            val strokeArray = groupJson.getJSONArray("strokes")
            val strokes = ArrayList<MacroStroke>(strokeArray.length())
            for (j in 0 until strokeArray.length()) {
                val strokeJson = strokeArray.getJSONObject(j)
                val pointArray = strokeJson.getJSONArray("points")
                val pointList = ArrayList<NormalizedPoint>(pointArray.length())
                for (k in 0 until pointArray.length()) {
                    val point = pointArray.getJSONObject(k)
                    pointList += NormalizedPoint(point.getDouble("x").toFloat(), point.getDouble("y").toFloat())
                }
                strokes += MacroStroke(strokeJson.getLong("startOffsetMs"), strokeJson.getLong("durationMs"), pointList)
            }
            groups += MacroGestureGroup(groupJson.getLong("startOffsetMs"), strokes)
        }

        val actions = ArrayList<MacroFlowAction>()
        if (version >= 2) {
            val actionsArray = json.optJSONArray("actions") ?: JSONArray()
            for (i in 0 until actionsArray.length()) {
                val actionJson = actionsArray.getJSONObject(i)
                actions += MacroFlowAction(
                    id = actionJson.getString("id"),
                    afterGroupCount = actionJson.getInt("afterGroupCount"),
                    type = MacroActionType.valueOf(actionJson.getString("type")),
                    packageName = actionJson.optString("packageName", ""),
                    appLabel = actionJson.optString("appLabel", ""),
                    waitAfterMs = actionJson.optLong("waitAfterMs", 2_500L)
                )
            }
        }

        val splitMarkers = ArrayList<Int>()
        if (version >= 3) {
            val splitsArray = json.optJSONArray("splitAfterGroupCounts") ?: JSONArray()
            for (i in 0 until splitsArray.length()) splitMarkers += splitsArray.getInt(i)
        }

        return TouchMacro(
            id = json.getString("id"),
            name = json.getString("name"),
            createdAt = json.getLong("createdAt"),
            recordedScreenWidth = json.getInt("recordedScreenWidth"),
            recordedScreenHeight = json.getInt("recordedScreenHeight"),
            totalDurationMs = json.getLong("totalDurationMs"),
            groups = groups,
            actions = actions,
            splitAfterGroupCounts = splitMarkers
        )
    }

    fun newId(): String = UUID.randomUUID().toString().replace("-", "")

    // ---------------------------- Library operations ----------------------------

    const val MAX_IMPORT_BYTES = 8 * 1024 * 1024
    const val MAX_IMPORT_MACROS = 500
    private const val BUNDLE_MARKER = "touchflowBackup"

    fun rename(context: Context, id: String, newName: String): TouchMacro {
        require(MacroNaming.isValidName(newName)) { "نام ماکرو باید بین ۱ تا ۴۰ نویسه باشد." }
        val macro = loadAll(context).firstOrNull { it.id == id } ?: throw IllegalStateException("ماکرو پیدا نشد.")
        return macro.copy(name = newName.trim()).also { save(context, it) }
    }

    fun duplicate(context: Context, id: String): TouchMacro {
        val macro = loadAll(context).firstOrNull { it.id == id } ?: throw IllegalStateException("ماکرو پیدا نشد.")
        return freshCopy(macro, MacroNaming.copyName(macro.name), System.currentTimeMillis()).also { save(context, it) }
    }

    private fun freshCopy(macro: TouchMacro, name: String, createdAt: Long) = macro.copy(
        id = newId(),
        name = name,
        createdAt = createdAt,
        actions = macro.actions.map { it.copy(id = newId()) }
    )

    fun exportMacro(macro: TouchMacro): String {
        validate(macro)
        return toJson(macro).toString(2)
    }

    fun exportAll(context: Context): String {
        val array = JSONArray()
        loadAll(context).forEach { array.put(toJson(it)) }
        return JSONObject()
            .put(BUNDLE_MARKER, 1)
            .put("exportedAt", System.currentTimeMillis())
            .put("macros", array)
            .toString(2)
    }

    /**
     * Parses a single-macro export or a backup bundle. Everything is validated before anything is saved.
     * Imported macros always get new ids, so an import can never overwrite an existing macro.
     */
    fun parseImported(text: String): List<TouchMacro> {
        require(text.length <= MAX_IMPORT_BYTES) { "فایل بیش از حد بزرگ است." }
        val root = try { JSONObject(text) } catch (_: Exception) { throw IllegalArgumentException("فایل ماکرو معتبر نیست.") }
        val objects: List<JSONObject> = if (root.has(BUNDLE_MARKER)) {
            val array = root.optJSONArray("macros") ?: throw IllegalArgumentException("فایل پشتیبان معتبر نیست.")
            require(array.length() in 1..MAX_IMPORT_MACROS) { "تعداد ماکروهای فایل پشتیبان معتبر نیست." }
            (0 until array.length()).map { array.optJSONObject(it) ?: throw IllegalArgumentException("فایل پشتیبان معتبر نیست.") }
        } else {
            listOf(root)
        }
        return objects.map { json ->
            val macro = try {
                fromJson(json)
            } catch (error: IllegalArgumentException) {
                throw error
            } catch (_: Exception) {
                throw IllegalArgumentException("ساختار فایل ماکرو معتبر نیست.")
            }
            validate(macro)
            freshCopy(macro, macro.name, macro.createdAt)
        }
    }

    /** Saves all or none: if a save fails, macros saved by this call are removed again. */
    fun importMacros(context: Context, macros: List<TouchMacro>) {
        val saved = mutableListOf<String>()
        try {
            macros.forEach { save(context, it); saved += it.id }
        } catch (error: Exception) {
            saved.forEach { delete(context, it) }
            throw error
        }
    }
}
