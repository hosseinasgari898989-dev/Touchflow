package com.grandmaconnect

/** Pure, Android-free search helpers (unit-testable). */
object SearchRules {
    /** Lower-cases, trims, unifies Arabic/Persian letter and digit variants, drops ZWNJ and tatweel. */
    fun normalize(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text.trim()) {
            when (ch) {
                'ي', 'ى' -> sb.append('ی')
                'ك' -> sb.append('ک')
                '\u200C', '\u200D', 'ـ' -> Unit
                in '٠'..'٩' -> sb.append('0' + (ch - '٠'))
                in '۰'..'۹' -> sb.append('0' + (ch - '۰'))
                else -> sb.append(ch.lowercaseChar())
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ")
    }

    /** Every whitespace-separated query token must occur in at least one field. Blank query matches all. */
    fun matches(query: String, vararg fields: String): Boolean {
        val tokens = normalize(query).split(' ').filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return true
        val haystack = fields.map { normalize(it) }
        return tokens.all { t -> haystack.any { it.contains(t) } }
    }
}
