package com.grandmaconnect

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.max

class TouchCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private data class ActiveStroke(
        val pointerId: Int,
        val startedAt: Long,
        val points: MutableList<NormalizedPoint> = mutableListOf(),
        var lastX: Float = 0f,
        var lastY: Float = 0f,
        var lastAt: Long = 0L
    )

    private val completedGroups = mutableListOf<MacroGestureGroup>()
    private val activeStrokes = linkedMapOf<Int, ActiveStroke>()
    private var currentGroupStrokes = mutableListOf<MacroStroke>()
    private var currentGroupStart = 0L
    private var recordingStart = 0L
    private var finalElapsedMs = 0L
    private var screenWidth = 0
    private var screenHeight = 0
    private var recording = false
    private var limitStopPending = false
    private var paused = false
    private var pausedAccumMs = 0L
    private var pauseStartedAt = 0L
    private var totalPointCount = 0
    private var captureProfile = MacroSettingsStore.load(context)

    private val limitRunnable = Runnable {
        if (recording) requestLimitStop("به سقف مدت ضبط انتخاب‌شده رسیدی.")
    }

    var onLimitReached: ((String) -> Unit)? = null

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(232, 237, 244)
        strokeWidth = dp(1f)
    }
    private val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(45, 105, 180)
        style = Paint.Style.STROKE
        strokeWidth = dp(5f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(45, 105, 180) }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(130, 140, 155)
        textSize = dp(16f)
        textAlign = Paint.Align.CENTER
    }

    init {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        isClickable = true
        contentDescription = "سطح ضبط حرکت انگشت"
    }

    fun startRecording(profile: MacroCaptureProfile = MacroSettingsStore.load(context)) {
        if (recording) return
        captureProfile = profile
        completedGroups.clear()
        activeStrokes.clear()
        currentGroupStrokes.clear()
        totalPointCount = 0
        finalElapsedMs = 0L
        limitStopPending = false
        paused = false
        pausedAccumMs = 0L
        currentScreenSize()
        recordingStart = clock()
        recording = true
        removeCallbacks(limitRunnable)
        postDelayed(limitRunnable, captureProfile.maxMacroDurationMs)
        invalidate()
    }

    fun stopRecording(): List<MacroGestureGroup> {
        if (recording) {
            val now = clock()
            finalElapsedMs = (now - recordingStart).coerceIn(1L, captureProfile.maxMacroDurationMs)
            val location = IntArray(2)
            getLocationOnScreen(location)
            activeStrokes.values.toList().forEach { stroke -> finishStroke(stroke, now) }
            activeStrokes.clear()
            finishGroup()
            recording = false
            paused = false
            limitStopPending = false
            removeCallbacks(limitRunnable)
        }
        invalidate()
        return completedGroups.toList()
    }

    fun isRecording(): Boolean = recording

    /** Recording clock that does not advance while paused, so pauses never become gaps in the macro. */
    private fun clock(): Long =
        (if (paused) pauseStartedAt else SystemClock.elapsedRealtime()) - pausedAccumMs

    fun isPaused(): Boolean = recording && paused

    /** Pausing is allowed only between complete touches, so no stroke is cut in half. */
    fun canPause(): Boolean = recording && !paused && !limitStopPending && activeStrokes.isEmpty() && currentGroupStrokes.isEmpty()

    fun pauseRecording(): Boolean {
        if (!canPause()) return false
        pauseStartedAt = SystemClock.elapsedRealtime()
        paused = true
        removeCallbacks(limitRunnable)
        invalidate()
        return true
    }

    fun resumeRecording(): Boolean {
        if (!recording || !paused) return false
        pausedAccumMs += SystemClock.elapsedRealtime() - pauseStartedAt
        paused = false
        removeCallbacks(limitRunnable)
        postDelayed(limitRunnable, (captureProfile.maxMacroDurationMs - elapsedMs()).coerceAtLeast(1L))
        invalidate()
        return true
    }

    /** Number of fully completed gesture groups; safe for inserting actions at boundaries. */
    fun completedGroupCount(): Int = completedGroups.size

    /** Actions may be inserted only between complete touch groups, never mid-stroke. */
    fun canInsertFlowAction(): Boolean = recording && !limitStopPending && activeStrokes.isEmpty() && currentGroupStrokes.isEmpty()

    fun elapsedMs(): Long = if (recording) {
        (clock() - recordingStart).coerceAtMost(captureProfile.maxMacroDurationMs)
    } else {
        finalElapsedMs
    }

    fun currentScreenSize(): Pair<Int, Int> {
        val metrics = android.util.DisplayMetrics()
        @Suppress("DEPRECATION")
        (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        screenWidth = max(1, metrics.widthPixels)
        screenHeight = max(1, metrics.heightPixels)
        return screenWidth to screenHeight
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
        val step = dp(32f)
        var x = 0f
        while (x <= width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += step
        }
        var y = 0f
        while (y <= height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += step
        }

        completedGroups.forEach { group -> group.strokes.forEach { drawStroke(canvas, it.points) } }
        activeStrokes.values.forEach { stroke -> drawNormalizedPath(canvas, stroke.points) }
        currentGroupStrokes.forEach { drawStroke(canvas, it.points) }

        if (completedGroups.isEmpty() && activeStrokes.isEmpty() && currentGroupStrokes.isEmpty()) {
            canvas.drawText("حرکت انگشت را داخل این کادر انجام بده", width / 2f, height / 2f, hintPaint)
            canvas.drawText("ضبط فقط در همین کادر انجام می‌شود", width / 2f, height / 2f + dp(28f), hintPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!recording || limitStopPending || paused) return true
        if (elapsedMs() >= captureProfile.maxMacroDurationMs) {
            requestLimitStop("به سقف مدت ضبط انتخاب‌شده رسیدی.")
            return true
        }
        val location = IntArray(2)
        getLocationOnScreen(location)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (completedGroups.size >= captureProfile.maxGroups) {
                    requestLimitStop("به سقف تعداد گروه‌های حرکت رسیدی.")
                    return true
                }
                currentGroupStrokes = mutableListOf()
                currentGroupStart = clock() - recordingStart
                addPointer(event, event.actionIndex, location)
                invalidate()
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (activeStrokes.size + currentGroupStrokes.size >= captureProfile.maxStrokesPerGroup) {
                    requestLimitStop("تعداد انگشت‌های هم‌زمان به سقف پشتیبانی‌شدهٔ این گوشی رسید.")
                    return true
                }
                addPointer(event, event.actionIndex, location)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) addPoint(event, i, location)
                invalidate()
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val pointerId = event.getPointerId(event.actionIndex)
                addPoint(event, event.actionIndex, location, force = true)
                activeStrokes.remove(pointerId)?.let { finishStroke(it, clock()) }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                val pointerId = event.getPointerId(event.actionIndex)
                addPoint(event, event.actionIndex, location, force = true)
                activeStrokes.remove(pointerId)?.let { finishStroke(it, clock()) }
                activeStrokes.values.toList().forEach { finishStroke(it, clock()) }
                activeStrokes.clear()
                finishGroup()
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                val now = clock()
                activeStrokes.values.toList().forEach { finishStroke(it, now) }
                activeStrokes.clear()
                finishGroup()
                invalidate()
                return true
            }
        }
        return true
    }

    private fun addPointer(event: MotionEvent, index: Int, location: IntArray) {
        if (totalPointCount >= captureProfile.maxTotalPoints) {
            requestLimitStop("به سقف تعداد نقاط ثبت‌شده رسیدی.")
            return
        }
        val id = event.getPointerId(index)
        val now = clock()
        val x = event.getX(index) + location[0]
        val y = event.getY(index) + location[1]
        val point = normalize(x, y)
        val stroke = ActiveStroke(id, now, mutableListOf(point), x, y, now)
        activeStrokes[id] = stroke
        totalPointCount++
    }

    private fun addPoint(event: MotionEvent, index: Int, location: IntArray, force: Boolean = false) {
        val id = event.getPointerId(index)
        val stroke = activeStrokes[id] ?: return
        val x = event.getX(index) + location[0]
        val y = event.getY(index) + location[1]
        val now = clock()
        val elapsedStroke = now - stroke.startedAt
        if (elapsedStroke > captureProfile.maxStrokeDurationMs) {
            requestLimitStop("مدت یک حرکت پیوسته از حد انتخاب‌شده فراتر رفت.")
            return
        }
        val movedEnough = abs(x - stroke.lastX) >= dp(captureProfile.minPointDistanceDp) ||
            abs(y - stroke.lastY) >= dp(captureProfile.minPointDistanceDp)
        val timeElapsed = now - stroke.lastAt >= captureProfile.sampleIntervalMs
        if (force || movedEnough || timeElapsed) {
            if (stroke.points.size >= captureProfile.maxPointsPerStroke || totalPointCount >= captureProfile.maxTotalPoints) {
                requestLimitStop("به سقف تعداد نقاط مسیر رسیدی.")
                return
            }
            stroke.points += normalize(x, y)
            totalPointCount++
            stroke.lastX = x
            stroke.lastY = y
            stroke.lastAt = now
        }
    }

    private fun normalize(x: Float, y: Float): NormalizedPoint {
        if (screenWidth <= 0 || screenHeight <= 0) currentScreenSize()
        return NormalizedPoint(
            (x / screenWidth.toFloat()).coerceIn(0f, 1f),
            (y / screenHeight.toFloat()).coerceIn(0f, 1f)
        )
    }

    private fun finishStroke(active: ActiveStroke, now: Long) {
        val rawStartOffset = (active.startedAt - (recordingStart + currentGroupStart)).coerceAtLeast(0L)
        val startOffset = rawStartOffset.coerceAtMost((captureProfile.platformMaxGestureDurationMs - 1L).coerceAtLeast(0L))
        val remainingGroupTime = (captureProfile.platformMaxGestureDurationMs - startOffset).coerceAtLeast(1L)
        val remainingMacroTime = (captureProfile.maxMacroDurationMs - currentGroupStart - startOffset).coerceAtLeast(1L)
        val duration = (now - active.startedAt).coerceAtLeast(1L)
            .coerceAtMost(captureProfile.maxStrokeDurationMs)
            .coerceAtMost(remainingGroupTime)
            .coerceAtMost(remainingMacroTime)
        val points = active.points.toList().ifEmpty { listOf(normalize(active.lastX, active.lastY)) }
        if (currentGroupStrokes.size < captureProfile.maxStrokesPerGroup) {
            currentGroupStrokes += MacroStroke(startOffset, duration, points)
        }
    }

    private fun finishGroup() {
        if (currentGroupStrokes.isNotEmpty() && completedGroups.size < captureProfile.maxGroups) {
            completedGroups += MacroGestureGroup(currentGroupStart.coerceAtLeast(0L), currentGroupStrokes.toList())
        }
        currentGroupStrokes.clear()
    }

    private fun requestLimitStop(message: String) {
        if (!recording || limitStopPending) return
        limitStopPending = true
        post {
            if (!recording) return@post
            stopRecording()
            onLimitReached?.invoke(message)
        }
    }

    private fun drawStroke(canvas: Canvas, points: List<NormalizedPoint>) = drawNormalizedPath(canvas, points)

    private fun drawNormalizedPath(canvas: Canvas, points: List<NormalizedPoint>) {
        if (points.isEmpty()) return
        val location = IntArray(2)
        getLocationOnScreen(location)
        if (screenWidth <= 0 || screenHeight <= 0) currentScreenSize()
        val path = Path()
        val first = points.first()
        val firstX = first.x * screenWidth - location[0]
        val firstY = first.y * screenHeight - location[1]
        path.moveTo(firstX, firstY)
        points.drop(1).forEach { point ->
            path.lineTo(point.x * screenWidth - location[0], point.y * screenHeight - location[1])
        }
        canvas.drawPath(path, pathPaint)
        canvas.drawCircle(firstX, firstY, dp(5f), dotPaint)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
