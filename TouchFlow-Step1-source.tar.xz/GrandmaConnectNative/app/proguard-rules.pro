# No custom ProGuard rules are required for the debug-first prototype.
