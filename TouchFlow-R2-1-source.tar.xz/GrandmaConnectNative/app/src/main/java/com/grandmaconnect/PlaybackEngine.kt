package com.grandmaconnect

/**
 * Pure playback state machine (no Android types) so pause/resume/stop can be unit-tested
 * with a fake clock. The AccessibilityService only supplies the timer and the host
 * operations (dispatch a touch group, run a flow action, show notifications).
 *
 * Rules:
 * - A touch group already handed to Android cannot be cancelled. Pause during a group
 *   becomes PAUSE_REQUESTED; when the group ends the engine goes to PAUSED WITHOUT
 *   running that boundary's actions. They run after resume.
 * - Pause during a wait keeps the exact remaining delay. Resume continues from there.
 * - Stop is terminal. Stop during a group waits for Android's result (STOPPING), with a
 *   watchdog in case the result never arrives. Late/stale results are ignored (run id).
 */
enum class PlaybackState { IDLE, STARTING, PLAYING, PAUSE_REQUESTED, PAUSED, STOPPING, STOPPED, COMPLETED, FAILED }

interface PlaybackTimer {
    interface Handle { fun cancel() }
    fun nowMs(): Long
    fun postDelayed(delayMs: Long, task: () -> Unit): Handle
}

interface PlaybackHost {
    /** Hands one touch group to Android; [onResult] must be called once with true=completed, false=cancelled. */
    fun dispatchGroup(index: Int, group: MacroGestureGroup, onResult: (completed: Boolean) -> Unit): Boolean

    /** Runs one flow action. Returns null on success or a user-facing error message. */
    fun runAction(action: MacroFlowAction): String?

    fun isOrientationCompatible(): Boolean

    fun onStateChanged(state: PlaybackState, groupIndex: Int, totalGroups: Int, message: String?)
}

class PlaybackEngine(private val timer: PlaybackTimer, private val host: PlaybackHost) {
    companion object {
        const val STOP_WATCHDOG_EXTRA_MS = 3_000L
    }

    var state: PlaybackState = PlaybackState.IDLE
        private set
    var groupIndex: Int = 0
        private set
    var totalGroups: Int = 0
        private set

    val isActive: Boolean
        get() = state == PlaybackState.STARTING ||
            state == PlaybackState.PLAYING ||
            state == PlaybackState.PAUSE_REQUESTED ||
            state == PlaybackState.PAUSED ||
            state == PlaybackState.STOPPING

    private var runId = 0L
    private var macro: TouchMacro? = null
    private var handle: PlaybackTimer.Handle? = null
    private var watchdog: PlaybackTimer.Handle? = null
    private var scheduledStep: (() -> Unit)? = null
    private var scheduledDueAt = 0L
    private var heldStep: (() -> Unit)? = null
    private var heldRemainingMs = 0L
    private var inFlight = false
    private var stateBeforePause = PlaybackState.PLAYING

    fun start(macro: TouchMacro, initialDelayMs: Long) {
        check(!isActive) { "یک ماکرو در حال اجراست." }
        require(initialDelayMs >= 0L) { "زمان شروع نامعتبر است." }
        clearTimers()
        runId++
        this.macro = macro
        totalGroups = macro.groups.size
        groupIndex = 0
        inFlight = false
        stateBeforePause = PlaybackState.STARTING
        setState(PlaybackState.STARTING, null)
        post(initialDelayMs) {
            setState(PlaybackState.PLAYING, null)
            runBoundaryActions(0) {
                post(macro.groups.firstOrNull()?.startOffsetMs ?: 0L) { dispatchGroup(0) }
            }
        }
    }

    /** True if the request changed anything; repeated requests are ignored. */
    fun pause(): Boolean {
        if (state != PlaybackState.PLAYING && state != PlaybackState.STARTING) return false
        if (inFlight) {
            stateBeforePause = PlaybackState.PLAYING
            setState(PlaybackState.PAUSE_REQUESTED, null)
            return true
        }
        val step = scheduledStep ?: return false
        handle?.cancel()
        handle = null
        heldStep = step
        heldRemainingMs = (scheduledDueAt - timer.nowMs()).coerceAtLeast(0L)
        scheduledStep = null
        stateBeforePause = state
        setState(PlaybackState.PAUSED, null)
        return true
    }

    fun resume(): Boolean {
        if (state == PlaybackState.PAUSE_REQUESTED) {
            setState(PlaybackState.PLAYING, null)
            return true
        }
        if (state != PlaybackState.PAUSED) return false
        val step = heldStep
        val remaining = heldRemainingMs
        heldStep = null
        heldRemainingMs = 0L
        setState(stateBeforePause, null)
        if (step == null) {
            fail("وضعیت اجرا نامعتبر بود؛ اجرا متوقف شد.")
        } else {
            post(remaining, step)
        }
        return true
    }

    fun stop(): Boolean {
        if (!isActive || state == PlaybackState.STOPPING) return false
        if (inFlight) {
            setState(PlaybackState.STOPPING, null)
            armWatchdog()
            return true
        }
        finishStopped()
        return true
    }

    /** Service is going away: cancel everything silently. Returns true if a run was active. */
    fun shutdown(): Boolean {
        val wasActive = isActive
        runId++
        clearTimers()
        inFlight = false
        macro = null
        if (wasActive) state = PlaybackState.STOPPED
        return wasActive
    }

    // ---- internals -------------------------------------------------------

    private fun post(delayMs: Long, step: () -> Unit) {
        val d = delayMs.coerceAtLeast(0L)
        if (state == PlaybackState.PAUSED) {
            heldStep = step
            heldRemainingMs = d
            return
        }
        val token = runId
        scheduledStep = step
        scheduledDueAt = timer.nowMs() + d
        handle = timer.postDelayed(d) {
            if (token == runId) {
                handle = null
                val next = scheduledStep
                scheduledStep = null
                if (next != null && (state == PlaybackState.STARTING || state == PlaybackState.PLAYING)) next()
            }
        }
    }

    private fun dispatchGroup(index: Int) {
        val m = macro ?: return
        if (index >= m.groups.size) {
            finishCompleted()
            return
        }
        if (!host.isOrientationCompatible()) {
            fail("جهت صفحه هنگام اجرای ماکرو تغییر کرد؛ برای جلوگیری از لمس اشتباه، اجرا متوقف شد.")
            return
        }
        groupIndex = index
        val token = runId
        inFlight = true
        val accepted = try {
            host.dispatchGroup(index, m.groups[index]) { completed -> onGestureResult(token, index, completed) }
        } catch (error: Exception) {
            inFlight = false
            fail("ساخت حرکت ناموفق بود: ${error.message ?: "خطای نامشخص"}")
            return
        }
        if (!accepted && inFlight) {
            inFlight = false
            fail("اندروید اجرای این حرکت را نپذیرفت.")
        }
    }

    private fun onGestureResult(token: Long, index: Int, completed: Boolean) {
        if (token != runId || !inFlight) return
        inFlight = false
        watchdog?.cancel()
        watchdog = null
        if (state == PlaybackState.STOPPING) {
            finishStopped()
        } else if (!completed) {
            fail("اجرای لمس توسط اندروید لغو شد.")
        } else if (state == PlaybackState.PAUSE_REQUESTED) {
            heldStep = { continueAfterGroup(index) }
            heldRemainingMs = 0L
            stateBeforePause = PlaybackState.PLAYING
            setState(PlaybackState.PAUSED, null)
        } else {
            continueAfterGroup(index)
        }
    }

    private fun continueAfterGroup(index: Int) {
        val completedCount = index + 1
        runBoundaryActions(completedCount) { afterBoundary(completedCount) }
    }

    private fun afterBoundary(completedCount: Int) {
        val m = macro ?: return
        if (completedCount >= m.groups.size) {
            finishCompleted()
            return
        }
        val previous = m.groups[completedCount - 1]
        val currentEnd = previous.startOffsetMs + (previous.strokes.maxOfOrNull { it.startOffsetMs + it.durationMs } ?: 0L)
        val nextStart = m.groups[completedCount].startOffsetMs
        val naturalGap = (nextStart - currentEnd).coerceAtLeast(0L)
        val actionWait = m.actions.filter { it.afterGroupCount == completedCount }.sumOf { it.waitAfterMs }
        post((naturalGap - actionWait).coerceAtLeast(0L)) { dispatchGroup(completedCount) }
    }

    private fun runBoundaryActions(afterGroupCount: Int, onDone: () -> Unit) {
        val m = macro ?: return
        runActionAt(m.actions.filter { it.afterGroupCount == afterGroupCount }, 0, onDone)
    }

    private fun runActionAt(actions: List<MacroFlowAction>, index: Int, onDone: () -> Unit) {
        if (index >= actions.size) {
            onDone()
            return
        }
        val action = actions[index]
        val error = try {
            host.runAction(action)
        } catch (e: Exception) {
            "اجرای اقدام ناموفق بود."
        }
        if (error != null) {
            fail(error)
            return
        }
        post(action.waitAfterMs) { runActionAt(actions, index + 1, onDone) }
    }

    private fun armWatchdog() {
        val group = macro?.groups?.getOrNull(groupIndex)
        val maxEnd = group?.strokes?.maxOfOrNull { it.startOffsetMs + it.durationMs } ?: 0L
        val token = runId
        watchdog = timer.postDelayed(maxEnd + STOP_WATCHDOG_EXTRA_MS) {
            if (token == runId && state == PlaybackState.STOPPING) {
                runId++ // a late result from Android is now ignored
                finishStopped()
            }
        }
    }

    private fun clearTimers() {
        handle?.cancel()
        handle = null
        watchdog?.cancel()
        watchdog = null
        scheduledStep = null
        heldStep = null
        heldRemainingMs = 0L
    }

    private fun finishStopped() {
        if (!isActive) return
        clearTimers()
        inFlight = false
        setState(PlaybackState.STOPPED, null)
    }

    private fun finishCompleted() {
        if (!isActive) return
        clearTimers()
        inFlight = false
        setState(PlaybackState.COMPLETED, null)
    }

    private fun fail(message: String) {
        if (!isActive) return
        clearTimers()
        inFlight = false
        setState(PlaybackState.FAILED, message)
    }

    private fun setState(newState: PlaybackState, message: String?) {
        if (state == newState && message == null) return
        state = newState
        host.onStateChanged(newState, groupIndex, totalGroups, message)
    }
}
