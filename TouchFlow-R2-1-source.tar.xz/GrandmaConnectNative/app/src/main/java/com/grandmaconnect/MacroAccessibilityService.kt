package com.grandmaconnect

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class MacroAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: MacroAccessibilityService? = null
            private set

        fun isEnabledInSettings(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val component = ComponentName(context, MacroAccessibilityService::class.java).flattenToString()
            return enabled.split(':').any { it.equals(component, ignoreCase = true) }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var currentMacroName = ""
    private var activeMacro: TouchMacro? = null
    private var lastNotifiedState = PlaybackState.IDLE
    private var currentNotificationId = 701
    private val channelId = "touchflow_macro_playback"

    /** Android-specific operations used by the pure [PlaybackEngine]. */
    private val playbackHost = object : PlaybackHost {
        override fun dispatchGroup(index: Int, group: MacroGestureGroup, onResult: (Boolean) -> Unit): Boolean {
            val gesture = buildGesture(group)
            updateNotification("در حال اجرای بخش ${index + 1} از ${activeMacro?.groups?.size ?: 0}")
            return this@MacroAccessibilityService.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    onResult(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    onResult(false)
                }
            }, handler)
        }

        override fun runAction(action: MacroFlowAction): String? {
            try {
                when (action.type) {
                    MacroActionType.LAUNCH_APP -> {
                        val launchIntent = packageManager.getLaunchIntentForPackage(action.packageName)
                            ?: return "برنامه «${action.appLabel}» نصب نیست یا راه‌اندازی آن در دسترس نیست."
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        this@MacroAccessibilityService.startActivity(launchIntent)
                        updateNotification("درخواست بازکردن «${action.appLabel}» ارسال شد")
                    }
                    MacroActionType.GO_HOME -> {
                        if (!performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)) {
                            return "اندروید فرمان رفتن به صفحه اصلی را نپذیرفت."
                        }
                        updateNotification("در حال رفتن به صفحه اصلی")
                    }
                    MacroActionType.GO_BACK -> {
                        if (!performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)) {
                            return "اندروید فرمان بازگشت را نپذیرفت."
                        }
                        updateNotification("در حال بازگشت به صفحه قبلی")
                    }
                    MacroActionType.GO_RECENTS -> {
                        if (!performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)) {
                            return "اندروید فرمان برنامه‌های اخیر را نپذیرفت."
                        }
                        updateNotification("در حال بازکردن برنامه‌های اخیر")
                    }
                    MacroActionType.OPEN_INTERNET_PANEL -> {
                        // Android does not let normal apps switch Wi-Fi/mobile data silently; the user does it in the system panel.
                        val panel = if (Build.VERSION.SDK_INT >= 29) {
                            Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                        } else {
                            Intent(Settings.ACTION_WIFI_SETTINGS)
                        }
                        panel.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        this@MacroAccessibilityService.startActivity(panel)
                        updateNotification("پنل اینترنت باز شد؛ تغییر را خودت انجام بده")
                    }
                }
            } catch (error: Exception) {
                val actionName = when (action.type) {
                    MacroActionType.LAUNCH_APP -> action.appLabel
                    MacroActionType.GO_HOME -> "صفحه اصلی"
                    MacroActionType.GO_BACK -> "بازگشت"
                    MacroActionType.GO_RECENTS -> "برنامه‌های اخیر"
                    MacroActionType.OPEN_INTERNET_PANEL -> "پنل اینترنت"
                }
                return "اجرای اقدام «$actionName» ناموفق بود."
            }
            return null
        }

        override fun isOrientationCompatible(): Boolean {
            val macro = activeMacro ?: return false
            return this@MacroAccessibilityService.isOrientationCompatible(macro)
        }

        override fun onStateChanged(state: PlaybackState, groupIndex: Int, totalGroups: Int, message: String?) {
            val previous = lastNotifiedState
            lastNotifiedState = state
            val wasPaused = previous == PlaybackState.PAUSED || previous == PlaybackState.PAUSE_REQUESTED
            when (state) {
                PlaybackState.PAUSE_REQUESTED ->
                    updateNotification("مکث ثبت شد؛ بعد از پایان حرکت جاری متوقف می‌شود")
                PlaybackState.PAUSED ->
                    updateNotification("مکث شد · بخش ${groupIndex + 1} از $totalGroups")
                PlaybackState.STARTING, PlaybackState.PLAYING ->
                    if (wasPaused) updateNotification("ادامهٔ اجرا · بخش ${groupIndex + 1} از $totalGroups")
                PlaybackState.STOPPING ->
                    updateNotification("درخواست توقف ثبت شد؛ حرکت لمسی جاری ممکن است کامل شود")
                PlaybackState.STOPPED -> {
                    updateNotification("ماکرو متوقف شد")
                    clearNotificationLater(3_000L)
                }
                PlaybackState.COMPLETED -> {
                    updateNotification("اجرای ماکرو تمام شد")
                    clearNotificationLater(4_000L)
                }
                PlaybackState.FAILED -> {
                    updateNotification(message ?: "اجرای ماکرو ناموفق بود")
                    clearNotificationLater(7_000L)
                }
                PlaybackState.IDLE -> Unit
            }
        }
    }

    private val engine = PlaybackEngine(HandlerPlaybackTimer(handler), playbackHost)

    val isPlaying: Boolean get() = engine.isActive
    val isPaused: Boolean
        get() = engine.state == PlaybackState.PAUSED || engine.state == PlaybackState.PAUSE_REQUESTED

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        createNotificationChannel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally does not inspect, read or store other apps' screen content.
    }

    override fun onInterrupt() {
        stopPlayback()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (engine.shutdown()) cancelNotification()
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun playMacro(macro: TouchMacro, initialDelayMs: Long = 3_000L) {
        if (engine.isActive) throw IllegalStateException("یک ماکرو در حال اجراست.")
        MacroStore.validate(macro)
        require(initialDelayMs in 0L..10_000L) { "زمان شروع نامعتبر است." }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            throw IllegalStateException("اجازه اعلان توقف فعال نیست.")
        }
        val displayMetrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(displayMetrics)
        val recordedPortrait = macro.recordedScreenHeight >= macro.recordedScreenWidth
        val currentPortrait = displayMetrics.heightPixels >= displayMetrics.widthPixels
        require(recordedPortrait == currentPortrait) { "جهت صفحه با زمان ضبط فرق دارد." }
        currentMacroName = macro.name
        activeMacro = macro
        lastNotifiedState = PlaybackState.IDLE
        engine.start(macro, initialDelayMs)
        showNotification("شروع تا ${initialDelayMs / 1000.0} ثانیه دیگر؛ توقف از اعلان در دسترس است")
    }

    /** Pause keeps the exact next step and its remaining delay; a touch already in flight finishes first. */
    fun pausePlayback() {
        engine.pause()
    }

    fun resumePlayback() {
        engine.resume()
    }

    fun stopPlayback() {
        engine.stop()
    }

    private fun clearNotificationLater(delayMs: Long) {
        handler.postDelayed({ if (!engine.isActive) cancelNotification() }, delayMs)
    }

    private fun isOrientationCompatible(macro: TouchMacro): Boolean {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val recordedPortrait = macro.recordedScreenHeight >= macro.recordedScreenWidth
        val currentPortrait = metrics.heightPixels >= metrics.widthPixels
        return recordedPortrait == currentPortrait
    }

    private fun buildGesture(group: MacroGestureGroup): GestureDescription {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val builder = GestureDescription.Builder()
        group.strokes.forEach { stroke ->
            val first = stroke.points.first()
            val path = Path().apply {
                moveTo(first.x * metrics.widthPixels, first.y * metrics.heightPixels)
                stroke.points.drop(1).forEach { point ->
                    lineTo(point.x * metrics.widthPixels, point.y * metrics.heightPixels)
                }
                if (stroke.points.size == 1) lineTo(first.x * metrics.widthPixels, first.y * metrics.heightPixels)
            }
            builder.addStroke(GestureDescription.StrokeDescription(path, stroke.startOffsetMs, stroke.durationMs))
        }
        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "وضعیت اجرای TouchFlow", NotificationManager.IMPORTANCE_LOW)
            channel.description = "وضعیت و توقف ماکروهای انتخاب‌شده توسط کاربر"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun actionPending(code: Int, action: String): PendingIntent = PendingIntent.getBroadcast(
        this, code,
        Intent(this, StopPlaybackReceiver::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun buildNotification(message: String, ongoing: Boolean): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        builder
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("TouchFlow · $currentMacroName")
            .setContentText(message)
            .setOngoing(ongoing)
        if (engine.isActive && engine.state != PlaybackState.STOPPING) {
            if (isPaused) {
                builder.addAction(Notification.Action.Builder(null, "ادامه", actionPending(704, StopPlaybackReceiver.ACTION_RESUME)).build())
            } else {
                builder.addAction(Notification.Action.Builder(null, "مکث", actionPending(703, StopPlaybackReceiver.ACTION_PAUSE)).build())
            }
        }
        builder.addAction(Notification.Action.Builder(null, "توقف فوری", actionPending(702, StopPlaybackReceiver.ACTION_STOP)).build())
        return builder.build()
    }

    private fun showNotification(message: String) = updateNotification(message)

    private fun updateNotification(message: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(currentNotificationId, buildNotification(message, engine.isActive))
        } catch (_: SecurityException) {
            // The UI requests notification permission before playback on Android 13+.
        }
    }

    private fun cancelNotification() {
        getSystemService(NotificationManager::class.java).cancel(currentNotificationId)
    }
}

class HandlerPlaybackTimer(private val handler: Handler) : PlaybackTimer {
    override fun nowMs(): Long = SystemClock.uptimeMillis()

    override fun postDelayed(delayMs: Long, task: () -> Unit): PlaybackTimer.Handle {
        val runnable = Runnable { task() }
        handler.postDelayed(runnable, delayMs)
        return object : PlaybackTimer.Handle {
            override fun cancel() {
                handler.removeCallbacks(runnable)
            }
        }
    }
}

class StopPlaybackReceiver : android.content.BroadcastReceiver() {
    companion object {
        const val ACTION_STOP = "com.grandmaconnect.STOP_PLAYBACK"
        const val ACTION_PAUSE = "com.grandmaconnect.PAUSE_PLAYBACK"
        const val ACTION_RESUME = "com.grandmaconnect.RESUME_PLAYBACK"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val service = MacroAccessibilityService.instance ?: return
        when (intent?.action) {
            ACTION_PAUSE -> service.pausePlayback()
            ACTION_RESUME -> service.resumePlayback()
            else -> service.stopPlayback()
        }
    }
}
