package com.grandmaconnect

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

/** Virtual clock: nothing here uses real time or Android. */
class FakePlaybackTimer : PlaybackTimer {
    private class Task(val id: Int, val due: Long, val action: () -> Unit) {
        var cancelled = false
    }

    var now = 0L
    private var seq = 0
    private val tasks = mutableListOf<Task>()

    override fun nowMs(): Long = now

    override fun postDelayed(delayMs: Long, task: () -> Unit): PlaybackTimer.Handle {
        val t = Task(seq++, now + delayMs.coerceAtLeast(0L), task)
        tasks.add(t)
        return object : PlaybackTimer.Handle {
            override fun cancel() {
                t.cancelled = true
            }
        }
    }

    val pending: Int get() = tasks.count { !it.cancelled }

    fun advanceBy(ms: Long) {
        val target = now + ms
        while (true) {
            val next = tasks.filter { !it.cancelled }.minWithOrNull(compareBy<Task>({ it.due }, { it.id })) ?: break
            if (next.due > target) break
            tasks.remove(next)
            if (next.due > now) now = next.due
            next.action()
        }
        now = target
    }
}

class FakePlaybackHost(private val timer: FakePlaybackTimer) : PlaybackHost {
    val log = mutableListOf<String>()
    val states = mutableListOf<PlaybackState>()
    var lastMessage: String? = null
    var autoComplete = false
    var orientationOk = true
    var acceptDispatch = true
    var throwOnDispatch: String? = null
    var actionError: String? = null
    var lastCallback: ((Boolean) -> Unit)? = null

    override fun dispatchGroup(index: Int, group: MacroGestureGroup, onResult: (Boolean) -> Unit): Boolean {
        val failure = throwOnDispatch
        if (failure != null) throw RuntimeException(failure)
        log.add("t=${timer.now} dispatch g$index")
        lastCallback = onResult
        if (autoComplete) {
            val duration = group.strokes.maxOfOrNull { it.startOffsetMs + it.durationMs } ?: 0L
            timer.postDelayed(duration) { onResult(true) }
        }
        return acceptDispatch
    }

    override fun runAction(action: MacroFlowAction): String? {
        log.add("t=${timer.now} action ${action.type}")
        return actionError
    }

    override fun isOrientationCompatible(): Boolean = orientationOk

    override fun onStateChanged(state: PlaybackState, groupIndex: Int, totalGroups: Int, message: String?) {
        states.add(state)
        lastMessage = message
    }

    fun finishGesture(completed: Boolean = true) {
        val callback = lastCallback
        assertNotNull(callback)
        callback!!(completed)
    }
}

class PlaybackEngineTest {
    private val timer = FakePlaybackTimer()
    private val host = FakePlaybackHost(timer)
    private val engine = PlaybackEngine(timer, host)

    private fun group(startMs: Long, durationMs: Long) =
        MacroGestureGroup(startMs, listOf(MacroStroke(0L, durationMs, listOf(NormalizedPoint(0.5f, 0.5f)))))

    private fun act(id: String, boundary: Int, type: MacroActionType, waitMs: Long) =
        MacroFlowAction(id = id, afterGroupCount = boundary, type = type, waitAfterMs = waitMs)

    private fun macro(groups: List<MacroGestureGroup>, actions: List<MacroFlowAction> = emptyList()) =
        TouchMacro("m1", "test", 0L, 1080, 2400, 10_000L, groups, actions)

    /** g0 (0..100) then g1 at 1100: after g0 completes at t=100 there is a 1000 ms gap. */
    private fun twoGroupsWithGap() = macro(listOf(group(0, 100), group(1100, 100)))

    @Test fun normalPlaybackRunsEverythingInOrderAtExactTimes() {
        host.autoComplete = true
        val m = macro(
            listOf(group(500, 100), group(2000, 100)),
            listOf(
                act("a1", 0, MacroActionType.GO_HOME, 200),
                act("a2", 1, MacroActionType.GO_BACK, 300),
                act("a3", 1, MacroActionType.LAUNCH_APP, 400)
            )
        )
        engine.start(m, 1_000L)
        timer.advanceBy(3_300L)
        assertEquals(
            listOf(
                "t=1000 action GO_HOME",
                "t=1700 dispatch g0",
                "t=1800 action GO_BACK",
                "t=2100 action LAUNCH_APP",
                "t=3200 dispatch g1"
            ),
            host.log
        )
        assertEquals(PlaybackState.COMPLETED, engine.state)
    }

    @Test fun pauseInGapKeepsExactRemainingDelay() {
        host.autoComplete = true
        engine.start(twoGroupsWithGap(), 0L)
        timer.advanceBy(400L) // g0 done at 100, gap due at 1100, now 400 -> 700 left
        assertTrue(engine.pause())
        assertEquals(PlaybackState.PAUSED, engine.state)
        timer.advanceBy(5_000L)
        assertEquals(1, host.log.size) // only g0 so far
        assertTrue(engine.resume())
        timer.advanceBy(699L)
        assertEquals(1, host.log.size)
        timer.advanceBy(1L)
        assertEquals("t=6100 dispatch g1", host.log.last())
        assertEquals(2, host.log.size)
    }

    @Test fun pauseDuringGestureDoesNotRunBoundaryActionUntilResume() {
        val m = macro(
            listOf(group(0, 1_000), group(5_000, 100)),
            listOf(act("a1", 1, MacroActionType.LAUNCH_APP, 500))
        )
        engine.start(m, 0L)
        timer.advanceBy(0L)
        assertEquals(listOf("t=0 dispatch g0"), host.log)
        assertTrue(engine.pause())
        assertEquals(PlaybackState.PAUSE_REQUESTED, engine.state)
        host.finishGesture(true)
        assertEquals(PlaybackState.PAUSED, engine.state)
        timer.advanceBy(10_000L)
        assertEquals(listOf("t=0 dispatch g0"), host.log) // the action must NOT fire while paused
        assertTrue(engine.resume())
        timer.advanceBy(0L)
        assertEquals("t=10000 action LAUNCH_APP", host.log[1])
        timer.advanceBy(4_000L) // wait 500 + remaining gap (4000-500)
        assertEquals("t=14000 dispatch g1", host.log[2])
        assertEquals(3, host.log.size)
    }

    @Test fun pauseDuringActionWaitKeepsRemainingWait() {
        val m = macro(listOf(group(0, 100)), listOf(act("a1", 0, MacroActionType.GO_HOME, 1_000)))
        engine.start(m, 0L)
        timer.advanceBy(400L) // action ran at 0, 600 ms of wait left
        assertEquals(listOf("t=0 action GO_HOME"), host.log)
        assertTrue(engine.pause())
        timer.advanceBy(3_000L)
        assertTrue(engine.resume())
        timer.advanceBy(599L)
        assertEquals(1, host.log.size)
        timer.advanceBy(1L)
        assertEquals("t=4000 dispatch g0", host.log.last())
        assertEquals(1, host.log.count { it.contains("GO_HOME") })
    }

    @Test fun pauseDuringStartDelayContinuesWithRemainingDelay() {
        val m = macro(listOf(group(0, 100)), listOf(act("a1", 0, MacroActionType.GO_HOME, 100)))
        engine.start(m, 3_000L)
        timer.advanceBy(500L)
        assertTrue(engine.pause())
        assertEquals(PlaybackState.PAUSED, engine.state)
        timer.advanceBy(10_000L)
        assertTrue(host.log.isEmpty())
        assertTrue(engine.resume())
        assertEquals(PlaybackState.STARTING, engine.state)
        timer.advanceBy(2_499L)
        assertTrue(host.log.isEmpty())
        timer.advanceBy(1L)
        assertEquals(listOf("t=13000 action GO_HOME"), host.log)
    }

    @Test fun resumeBeforeGestureEndCancelsThePauseRequest() {
        val m = macro(listOf(group(0, 1_000), group(1_000, 100)))
        engine.start(m, 0L)
        timer.advanceBy(0L)
        assertTrue(engine.pause())
        assertTrue(engine.resume())
        assertEquals(PlaybackState.PLAYING, engine.state)
        host.finishGesture(true)
        timer.advanceBy(0L)
        assertEquals(listOf("t=0 dispatch g0", "t=0 dispatch g1"), host.log)
    }

    @Test fun pauseOnLastGestureCompletesOnlyAfterResume() {
        engine.start(macro(listOf(group(0, 100))), 0L)
        timer.advanceBy(0L)
        assertTrue(engine.pause())
        host.finishGesture(true)
        assertEquals(PlaybackState.PAUSED, engine.state)
        timer.advanceBy(5_000L)
        assertEquals(PlaybackState.PAUSED, engine.state)
        assertTrue(engine.resume())
        timer.advanceBy(0L)
        assertEquals(PlaybackState.COMPLETED, engine.state)
    }

    @Test fun stopWhileWaitingCancelsEverything() {
        host.autoComplete = true
        engine.start(twoGroupsWithGap(), 0L)
        timer.advanceBy(400L)
        assertTrue(engine.stop())
        assertEquals(PlaybackState.STOPPED, engine.state)
        assertEquals(0, timer.pending)
        timer.advanceBy(100_000L)
        assertEquals(1, host.log.size)
        assertFalse(engine.stop())
    }

    @Test fun stopWhilePausedIsTerminal() {
        host.autoComplete = true
        engine.start(twoGroupsWithGap(), 0L)
        timer.advanceBy(400L)
        assertTrue(engine.pause())
        assertTrue(engine.stop())
        assertEquals(PlaybackState.STOPPED, engine.state)
        assertEquals(0, timer.pending)
        timer.advanceBy(100_000L)
        assertEquals(1, host.log.size)
        assertFalse(engine.resume())
    }

    @Test fun stopAfterPauseRequestWaitsForGestureAndRunsNoAction() {
        val m = macro(listOf(group(0, 100), group(500, 100)), listOf(act("a1", 1, MacroActionType.GO_HOME, 100)))
        engine.start(m, 0L)
        timer.advanceBy(0L)
        assertTrue(engine.pause())
        assertTrue(engine.stop())
        assertEquals(PlaybackState.STOPPING, engine.state)
        try {
            engine.start(m, 0L)
            fail("a second run must not start while the first is still stopping")
        } catch (expected: IllegalStateException) {
        }
        host.finishGesture(true)
        assertEquals(PlaybackState.STOPPED, engine.state)
        timer.advanceBy(100_000L)
        assertEquals(listOf("t=0 dispatch g0"), host.log)
    }

    @Test fun staleResultFromOldRunCannotAffectNewRun() {
        val m = macro(listOf(group(0, 100), group(500, 100)))
        engine.start(m, 0L)
        timer.advanceBy(0L)
        val oldCallback = host.lastCallback!!
        assertTrue(engine.stop())
        timer.advanceBy(3_100L) // watchdog fires, old result never came
        assertEquals(PlaybackState.STOPPED, engine.state)
        engine.start(m, 0L)
        timer.advanceBy(0L)
        assertEquals(2, host.log.size)
        oldCallback(true) // late result of the first run
        oldCallback(false)
        assertEquals(PlaybackState.PLAYING, engine.state)
        assertEquals(2, host.log.size)
        host.finishGesture(true)
        timer.advanceBy(400L)
        assertEquals("t=3500 dispatch g1", host.log.last())
    }

    @Test fun stopWatchdogEndsStoppingIfAndroidNeverReports() {
        engine.start(macro(listOf(group(0, 100))), 0L)
        timer.advanceBy(0L)
        assertTrue(engine.stop())
        timer.advanceBy(3_099L)
        assertEquals(PlaybackState.STOPPING, engine.state)
        timer.advanceBy(1L)
        assertEquals(PlaybackState.STOPPED, engine.state)
        assertEquals(0, timer.pending)
    }

    @Test fun rapidCommandsNeverDuplicateOrReorderWork() {
        host.autoComplete = true
        engine.start(twoGroupsWithGap(), 0L)
        timer.advanceBy(400L)
        val results = listOf(
            engine.pause(), engine.pause(), engine.resume(), engine.resume(),
            engine.pause(), engine.resume(), engine.resume()
        )
        assertEquals(listOf(true, false, true, false, true, true, false), results)
        timer.advanceBy(10_000L)
        assertEquals(listOf("t=0 dispatch g0", "t=1100 dispatch g1"), host.log)
        assertEquals(PlaybackState.COMPLETED, engine.state)
    }

    @Test fun finishedRunIgnoresCommandsAndAllowsANewRun() {
        host.autoComplete = true
        engine.start(macro(listOf(group(0, 100))), 0L)
        timer.advanceBy(100L)
        assertEquals(PlaybackState.COMPLETED, engine.state)
        assertEquals(1, host.states.count { it == PlaybackState.COMPLETED })
        assertFalse(engine.pause())
        assertFalse(engine.resume())
        assertFalse(engine.stop())
        engine.start(macro(listOf(group(0, 100))), 0L)
        timer.advanceBy(100L)
        assertEquals(2, host.log.size)
        assertEquals(PlaybackState.COMPLETED, engine.state)
    }

    @Test fun emptyMacroCompletesWithoutDispatching() {
        engine.start(macro(emptyList()), 0L)
        timer.advanceBy(0L)
        assertEquals(PlaybackState.COMPLETED, engine.state)
        assertTrue(host.log.isEmpty())
    }

    @Test fun failedActionStopsRunAndReportsMessage() {
        host.actionError = "boom"
        val m = macro(listOf(group(0, 100)), listOf(act("a1", 0, MacroActionType.LAUNCH_APP, 100)))
        engine.start(m, 0L)
        timer.advanceBy(10_000L)
        assertEquals(PlaybackState.FAILED, engine.state)
        assertEquals("boom", host.lastMessage)
        assertEquals(listOf("t=0 action LAUNCH_APP"), host.log)
    }

    @Test fun orientationChangeFailsBeforeAnyTouch() {
        host.orientationOk = false
        engine.start(macro(listOf(group(0, 100))), 0L)
        timer.advanceBy(0L)
        assertEquals(PlaybackState.FAILED, engine.state)
        assertTrue(host.lastMessage!!.contains("جهت صفحه"))
        assertTrue(host.log.isEmpty())
    }

    @Test fun rejectedOrThrowingDispatchFailsTheRun() {
        host.acceptDispatch = false
        engine.start(macro(listOf(group(0, 100))), 0L)
        timer.advanceBy(0L)
        assertEquals(PlaybackState.FAILED, engine.state)
        host.acceptDispatch = true
        host.throwOnDispatch = "bad"
        engine.start(macro(listOf(group(0, 100))), 0L)
        timer.advanceBy(0L)
        assertEquals(PlaybackState.FAILED, engine.state)
        assertTrue(host.lastMessage!!.contains("ساخت حرکت ناموفق بود"))
        assertTrue(host.lastMessage!!.contains("bad"))
    }

    @Test fun cancelledGestureFailsEvenWhenPauseWasRequested() {
        engine.start(macro(listOf(group(0, 100), group(500, 100))), 0L)
        timer.advanceBy(0L)
        assertTrue(engine.pause())
        host.finishGesture(false)
        assertEquals(PlaybackState.FAILED, engine.state)
        timer.advanceBy(10_000L)
        assertEquals(1, host.log.size)
    }

    @Test fun shutdownCancelsEverythingSilently() {
        host.autoComplete = true
        engine.start(twoGroupsWithGap(), 0L)
        timer.advanceBy(400L)
        val statesBefore = host.states.size
        assertTrue(engine.shutdown())
        assertEquals(0, timer.pending)
        assertFalse(engine.isActive)
        timer.advanceBy(100_000L)
        assertEquals(1, host.log.size)
        assertEquals(statesBefore, host.states.size)
        assertFalse(engine.shutdown())
    }

    @Test fun launchAppAndNavigationActionsRunInSavedOrderWithTheirWaits() {
        val m = macro(
            listOf(group(0, 100)),
            listOf(
                act("a1", 0, MacroActionType.LAUNCH_APP, 100),
                act("a2", 0, MacroActionType.GO_HOME, 200),
                act("a3", 0, MacroActionType.GO_BACK, 300),
                act("a4", 0, MacroActionType.GO_RECENTS, 400),
                act("a5", 0, MacroActionType.OPEN_INTERNET_PANEL, 500)
            )
        )
        engine.start(m, 0L)
        timer.advanceBy(2_000L)
        assertEquals(
            listOf(
                "t=0 action LAUNCH_APP",
                "t=100 action GO_HOME",
                "t=300 action GO_BACK",
                "t=600 action GO_RECENTS",
                "t=1000 action OPEN_INTERNET_PANEL",
                "t=1500 dispatch g0"
            ),
            host.log
        )
    }
}
